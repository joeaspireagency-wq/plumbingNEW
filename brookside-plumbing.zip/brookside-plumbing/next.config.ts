import type { NextConfig } from "next";

/**
 * Normal builds (Vercel free tier) keep next/image optimisation.
 * `npm run build:static` sets STATIC_EXPORT=1 to produce a plain /out folder for
 * any free static host or the single-file preview. Images are pre-optimised
 * (SVG / sized PNG), so `images.unoptimized` is a deliberate choice there.
 */
const isStaticExport = process.env.STATIC_EXPORT === "1";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  ...(isStaticExport
    ? { output: "export" as const, images: { unoptimized: true } }
    : {}),
};

export default nextConfig;
