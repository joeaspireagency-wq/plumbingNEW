"use client";

import { useEffect } from "react";

/**
 * Tiny IntersectionObserver hook. Marks every `[data-observe]` element with
 * `data-inview="true|false"`. CSS uses that to pause off-screen animation
 * (floating shapes, waves) and to start one-shot draws (`data-once`).
 * Also sets `data-js` on <html> so no-JS visitors always see static content.
 */
export function useInViewToggle() {
  useEffect(() => {
    document.documentElement.setAttribute("data-js", "1");

    const targets = document.querySelectorAll<HTMLElement>("[data-observe]");
    if (typeof IntersectionObserver === "undefined") {
      targets.forEach((el) => el.setAttribute("data-inview", "true"));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          const el = entry.target as HTMLElement;
          const once = el.hasAttribute("data-once");
          if (entry.isIntersecting) {
            el.setAttribute("data-inview", "true");
            if (once) io.unobserve(el);
          } else if (!once) {
            el.setAttribute("data-inview", "false");
          }
        }
      },
      { rootMargin: "120px 0px" },
    );

    targets.forEach((el) => {
      if (!el.hasAttribute("data-inview")) el.setAttribute("data-inview", "false");
      io.observe(el);
    });

    return () => io.disconnect();
  }, []);
}
