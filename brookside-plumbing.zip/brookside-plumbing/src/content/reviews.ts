/** SAMPLE CONTENT: fictional reviews, always labelled as samples on the page. */
import { z } from "zod";

const ReviewSchema = z.object({
  id: z.string(),
  stars: z.number().int().min(1).max(5),
  quote: z.string(),
  name: z.string(),
  area: z.string(),
  job: z.string(),
  when: z.string(),
});

export type Review = z.infer<typeof ReviewSchema>;

export const reviews: Review[] = z.array(ReviewSchema).parse([
  {
    id: "sarah",
    stars: 5,
    quote:
      "Water was coming through the kitchen ceiling at 9pm. Liam was here in 40 minutes, stopped it, and gave me a fixed price before he touched anything. Final bill was exactly that.",
    name: "Sarah",
    area: "West Bridgford",
    job: "Burst pipe",
    when: "2 weeks ago",
  },
  {
    id: "mark",
    stars: 5,
    quote:
      "Quoted £3,450, paid £3,450. They tidied up every evening and the room looks fantastic.",
    name: "Mark",
    area: "Beeston",
    job: "Bathroom install",
    when: "2 weeks ago",
  },
  {
    id: "priya",
    stars: 5,
    quote:
      "Sent the form in a minute, heard back within the hour, fixed next morning. They turned up in the window they gave and texted when on the way.",
    name: "Priya",
    area: "Arnold",
    job: "Leaking tap",
    when: "2 weeks ago",
  },
  {
    id: "dave",
    stars: 5,
    quote:
      "I look after four flats. Liam sends photos after every job so I can pass them to tenants. I've never had to chase.",
    name: "Dave",
    area: "Carlton",
    job: "Landlord",
    when: "2 weeks ago",
  },
  {
    id: "hannah",
    stars: 5,
    quote:
      "Another firm quoted double over the phone. Liam gave a clear price, cleared it in an hour, and showed me how to stop it happening again.",
    name: "Hannah",
    area: "Nottingham NG3",
    job: "Blocked drain",
    when: "2 weeks ago",
  },
  {
    id: "gary",
    stars: 5,
    quote: "Small jobs, but treated with real care. Polite, clean, fair price.",
    name: "Gary",
    area: "West Bridgford",
    job: "Toilet and radiator",
    when: "2 weeks ago",
  },
]);
