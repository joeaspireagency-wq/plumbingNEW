/** SAMPLE CONTENT: one fictional demonstration project. */
import { z } from "zod";

const BeforeAfterSchema = z.object({
  title: z.string(),
  duration: z.string(),
  quoted: z.string(),
  finalBill: z.string(),
  result: z.string(),
  beforeImageId: z.string(),
  afterImageId: z.string(),
  sliderLabel: z.string(),
});

export const beforeAfter = BeforeAfterSchema.parse({
  title: "Leaking shower and tired bathroom, Beeston",
  duration: "5 days",
  quoted: "£3,450",
  finalBill: "£3,450",
  result: "New suite, no leaks, 5-year guarantee.",
  beforeImageId: "beforeafter-before",
  afterImageId: "beforeafter-after",
  sliderLabel:
    "Comparison slider. Drag left or right, or use the arrow keys, to compare the bathroom before and after.",
});
