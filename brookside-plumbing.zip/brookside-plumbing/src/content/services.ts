/** SAMPLE CONTENT: services, programs and quote-form options. */
import { z } from "zod";

export const SERVICE_IDS = [
  "leaks-bursts",
  "taps-toilets",
  "blocked-drains",
  "radiators-cylinders",
  "bathrooms",
  "emergency",
  "something-else",
] as const;

export type ServiceId = (typeof SERVICE_IDS)[number];

export const ICON_KEYS = [
  "droplets",
  "wrench",
  "waves",
  "heater",
  "bath",
  "siren",
  "help",
  "house",
] as const;

const QuoteServiceSchema = z.object({
  id: z.enum(SERVICE_IDS),
  label: z.string(),
  hint: z.string(),
  icon: z.enum(ICON_KEYS),
});

/** The 6 services (plus "Something else") shown in the quote form and chip row. */
export const quoteServices = z.array(QuoteServiceSchema).parse([
  { id: "leaks-bursts", label: "Leaks and bursts", hint: "Pipes, ceilings, under sinks", icon: "droplets" },
  { id: "taps-toilets", label: "Taps and toilets", hint: "Dripping, running, loose", icon: "wrench" },
  { id: "blocked-drains", label: "Blocked drains", hint: "Sinks, baths, outside drains", icon: "waves" },
  { id: "radiators-cylinders", label: "Radiators and cylinders", hint: "Swap, move or repair", icon: "heater" },
  { id: "bathrooms", label: "Bathrooms", hint: "Full suite fit or refresh", icon: "bath" },
  { id: "emergency", label: "Emergency call-outs", hint: "Flooding, no water, 24/7", icon: "siren" },
  { id: "something-else", label: "Something else", hint: "Tell us on the next steps", icon: "help" },
]);

const ProgramSchema = z.object({
  id: z.string(),
  name: z.string(),
  icon: z.enum(ICON_KEYS),
  popular: z.boolean().default(false),
  benefit: z.string(),
  time: z.string(),
  priceFrom: z.string(),
  priceSuffix: z.string().optional(),
  features: z.tuple([z.string(), z.string(), z.string(), z.string()]),
  /** Nearest quote-form service to pre-select */
  service: z.enum(SERVICE_IDS),
  emergency: z.boolean().default(false),
  imageId: z.string(),
});

export type Program = z.infer<typeof ProgramSchema>;

export const programs: Program[] = z.array(ProgramSchema).parse([
  {
    id: "fast-fix",
    name: "Fast Fix",
    icon: "wrench",
    popular: true,
    benefit: "Taps, toilets, leaks and blockages, usually sorted in one visit.",
    time: "Typically 1–3 hours",
    priceFrom: "£85",
    features: [
      "Fixed price before we start",
      "Same-day or next-day slots",
      "Van stocked with common parts",
      "Tidy-up included",
    ],
    service: "taps-toilets",
    imageId: "program-fast-fix",
  },
  {
    id: "emergency-response",
    name: "Emergency Response",
    icon: "siren",
    benefit: "Burst pipe or flooding? We stop the water first.",
    time: "24/7 · Burst pipes, flooding, no water",
    priceFrom: "£95",
    priceSuffix: "out of hours",
    features: [
      "We stop the leak first, then quote the repair",
      "Typical arrival within about an hour in NG postcodes (sample)",
      "Same fixed-price promise, day or night",
      "Photo report of what we found and fixed",
    ],
    service: "emergency",
    emergency: true,
    imageId: "program-emergency",
  },
  {
    id: "bathroom-makeover",
    name: "Bathroom Makeover",
    icon: "bath",
    benefit: "A full new suite, fitted to a price that doesn't move.",
    time: "Typically 4–6 days",
    priceFrom: "£3,200",
    features: [
      "Free home survey and written fixed-price quote",
      "Tiling, electrics and plastering coordinated",
      "Staged payments, no big upfront bill",
      "Dust sheets and daily tidy-up",
    ],
    service: "bathrooms",
    imageId: "program-bathroom",
  },
  {
    id: "landlord-home-care",
    name: "Landlord and Home Care",
    icon: "house",
    benefit: "Planned visits and priority booking, one number for every property.",
    time: "Planned visits, priority response",
    priceFrom: "£120",
    priceSuffix: "a year",
    features: [
      "Annual plumbing health-check",
      "Priority response for plan members",
      "Photo reports you can pass to tenants",
      "One number for all your properties",
    ],
    service: "something-else",
    imageId: "program-landlord",
  },
]);
