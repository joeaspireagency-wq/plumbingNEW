/** SAMPLE CONTENT: trust badges, steps. Plain and specific; no absolutes. */
import { z } from "zod";

const TrustBadgeSchema = z.object({
  title: z.string(),
  detail: z.string(),
  icon: z.enum(["water", "member", "insured", "guarantee"]),
});

export const trustBadges = z.array(TrustBadgeSchema).parse([
  { title: "WaterSafe registered", detail: "Approved plumber scheme", icon: "water" },
  { title: "CIPHE member", detail: "Chartered plumbing body", icon: "member" },
  { title: "£2m insured", detail: "Public liability cover", icon: "insured" },
  { title: "5-year guarantee", detail: "On our workmanship", icon: "guarantee" },
]);

export const everyJobIncludes = z.array(z.string()).parse([
  "Fixed price in writing",
  "Insured and WaterSafe registered",
  "Tidy-up",
  "Photo report",
  "5-year workmanship guarantee",
]);

export const steps = z
  .array(z.object({ title: z.string(), text: z.string() }))
  .parse([
    {
      title: "Tell us",
      text: "Pick the job, add your postcode and leave a number. It takes about 60 seconds.",
    },
    {
      title: "Get a fixed price",
      text: "We reply within the hour in working hours with a price in writing. No hourly rate.",
    },
    {
      title: "We fix it",
      text: "Choose a time window. We text when we're on our way, fix it, tidy up and send photos.",
    },
  ]);
