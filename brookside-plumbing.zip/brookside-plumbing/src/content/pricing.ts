/** SAMPLE CONTENT: prices are for demonstration only. No hourly rate is shown. */
import { z } from "zod";

const PriceRowSchema = z.object({
  id: z.string(),
  label: z.string(),
  note: z.string().optional(),
  from: z.string(),
  suffix: z.string().optional(),
  popular: z.boolean().default(false),
  outOfHours: z.boolean().default(false),
});

export type PriceRowData = z.infer<typeof PriceRowSchema>;

export const priceRows: PriceRowData[] = z.array(PriceRowSchema).parse([
  {
    id: "diagnosis",
    label: "Call-out and diagnosis",
    note: "Credited back if you go ahead",
    from: "£65",
  },
  {
    id: "tap-toilet",
    label: "Tap or toilet repair",
    note: "Part of our Fast Fix service",
    from: "£85",
    popular: true,
  },
  { id: "drain", label: "Blocked drain or sink", from: "£110" },
  { id: "leak", label: "Leak repair or burst pipe", from: "£120" },
  { id: "radiator", label: "Radiator replacement", from: "£140", suffix: "each" },
  {
    id: "out-of-hours",
    label: "Emergency out-of-hours call-out",
    note: "Evenings, Sundays and bank holidays",
    from: "£95",
    outOfHours: true,
  },
  { id: "bathroom", label: "Full bathroom installation", note: "Free survey, staged payments", from: "£3,200" },
]);

export const pricingCopy = {
  title: "Clear prices, no surprises",
  lead: "Most plumbers won't talk numbers until they're in your kitchen. We'd rather you knew where you stand.",
  principles: [
    { title: "Fixed price", text: "Agreed in writing before any work starts." },
    { title: "Guaranteed work", text: "Five years on our workmanship." },
    { title: "No call-out surprises", text: "Diagnosis fee comes off the job if you go ahead." },
  ],
  payment:
    "Repairs are paid on completion. Bathrooms are paid in stages. Card or bank transfer.",
} as const;
