/** SAMPLE CONTENT: objection-removing FAQs. Also feeds the FAQPage JSON-LD. */
import { z } from "zod";

const FaqSchema = z.object({ id: z.string(), q: z.string(), a: z.string() });
export type Faq = z.infer<typeof FaqSchema>;

export const faqs: Faq[] = z.array(FaqSchema).parse([
  {
    id: "hidden-costs",
    q: "Will there be hidden costs?",
    a: "No. You get a written fixed price before we start. If we find something extra, we stop, explain it, and you decide.",
  },
  {
    id: "call-out-fee",
    q: "Do I pay a call-out fee if I don't go ahead?",
    a: "The quote itself is free. If we visit to diagnose, the call-out from £65 is credited against the job if you go ahead.",
  },
  {
    id: "how-fast",
    q: "How fast can you come?",
    a: "Most quotes come back within an hour in working hours. Fast Fix jobs are usually same or next day. Emergencies are 24/7.",
  },
  {
    id: "qualified",
    q: "How do I know you're qualified and insured?",
    a: "We're WaterSafe registered, CIPHE members and carry £2m public liability insurance. Ask and we'll send the certificates before the job.",
  },
  {
    id: "after-job",
    q: "What if something goes wrong after the job?",
    a: "Our work is guaranteed for 5 years. Call us and we'll come back and put it right, free of charge.",
  },
  {
    id: "small-jobs",
    q: "Do you take on small jobs?",
    a: "Yes. A dripping tap gets the same care as a bathroom.",
  },
  {
    id: "payment",
    q: "How and when do I pay?",
    a: "Repairs are paid on completion. Bathrooms are paid in stages, so there's no big upfront bill. Card or bank transfer.",
  },
]);
