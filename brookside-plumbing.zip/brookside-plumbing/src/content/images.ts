/**
 * Image slots. Every image is hosted locally in /public/images (never hotlinked).
 *
 * SAMPLE CONTENT: the images supplied with this prototype are original vector
 * illustrations made for the demo, so they carry no third-party licence.
 * To go live, drop real project photos into /public/images using the same file
 * names (or update `src` here) and keep the width/height ratio. See
 * public/images/README.md for the required dimensions of each slot.
 */
import { z } from "zod";

const ImageSchema = z.object({
  id: z.string(),
  src: z.string().startsWith("/images/"),
  alt: z.string(),
  width: z.number().int().positive(),
  height: z.number().int().positive(),
  sizes: z.string(),
  priority: z.boolean().default(false),
  /** CSS object-position, e.g. "50% 30%" */
  focal: z.string().optional(),
  credit: z.string(),
});

export type SiteImageData = z.infer<typeof ImageSchema> & { aspect: string };

const raw = z.array(ImageSchema).parse([
  {
    id: "hero-bg",
    src: "/images/hero-bg.jpg",
    alt: "",
    width: 1280,
    height: 655,
    sizes: "100vw",
    priority: true,
    focal: "42% 50%",
    credit: "Hero background photo supplied for this prototype (shown slightly blurred under a navy overlay).",
  },
  {
    id: "about-liam",
    src: "/images/about-liam.jpg",
    alt: "Liam Hartnett, owner of Brookside Plumbing, smiling as he works with his toolkit beside him",
    width: 960,
    height: 1055,
    sizes: "(min-width: 1024px) 420px, (min-width: 640px) 60vw, 100vw",
    focal: "50% 30%",
    credit: "Owner photo supplied for this prototype.",
  },
  {
    id: "beforeafter-before",
    src: "/images/beforeafter-before.jpg",
    alt: "Before: a dated bathroom with stained, mouldy beige tiles, an old pedestal basin and a worn shower enclosure",
    width: 1200,
    height: 900,
    sizes: "(min-width: 1024px) 680px, 100vw",
    credit: "Before photo supplied for this prototype.",
  },
  {
    id: "beforeafter-after",
    src: "/images/beforeafter-after.jpg",
    alt: "After: the bathroom refitted with navy tiles, a white vanity unit with round mirror and a glass walk-in shower",
    width: 1200,
    height: 900,
    sizes: "(min-width: 1024px) 680px, 100vw",
    credit: "After photo supplied for this prototype.",
  },
  {
    id: "program-fast-fix",
    src: "/images/program-fast-fix.jpg",
    alt: "A chrome sink trap and valves under a basin with water dripping from a leaking joint",
    width: 960,
    height: 600,
    sizes: "(min-width: 1280px) 280px, (min-width: 768px) 45vw, 100vw",
    focal: "45% 50%",
    credit: "Fast Fix photo supplied for this prototype.",
  },
  {
    id: "program-emergency",
    src: "/images/program-emergency.jpg",
    alt: "A burst copper pipe under a basin spraying water across a bathroom floor",
    width: 960,
    height: 600,
    sizes: "(min-width: 1280px) 280px, (min-width: 768px) 45vw, 100vw",
    focal: "50% 50%",
    credit: "Emergency Response photo supplied for this prototype.",
  },
  {
    id: "program-bathroom",
    src: "/images/program-bathroom.jpg",
    alt: "A new freestanding white bath against a navy tiled wall with a floor-standing chrome tap",
    width: 960,
    height: 600,
    sizes: "(min-width: 1280px) 280px, (min-width: 768px) 45vw, 100vw",
    focal: "50% 50%",
    credit: "Bathroom Makeover photo supplied for this prototype.",
  },
  {
    id: "program-landlord",
    src: "/images/program-landlord.jpg",
    alt: "A Brookside plumber in a navy polo shows a homeowner a checklist on his tablet in her hallway",
    width: 960,
    height: 600,
    sizes: "(min-width: 1280px) 280px, (min-width: 768px) 45vw, 100vw",
    focal: "50% 35%",
    credit: "Landlord and Home Care photo supplied for this prototype.",
  },
  {
    id: "og-image",
    src: "/images/og-image.png",
    alt: "Brookside Plumbing, Nottingham. Tell us the problem, get a fixed price.",
    width: 1200,
    height: 630,
    sizes: "1200px",
    credit: "Generated from the brand tokens for this prototype.",
  },
]);

export const images: SiteImageData[] = raw.map((i) => ({
  ...i,
  aspect: `${i.width} / ${i.height}`,
}));

export function getImage(id: string): SiteImageData {
  const found = images.find((i) => i.id === id);
  if (!found) {
    // Never crash the page for a missing slot: fall back to the first image.
    return images[0];
  }
  return found;
}
