"use client";

import { ArrowLeft, ArrowRight, CircleAlert, CircleCheck, LoaderCircle, X } from "lucide-react";
import { useCallback, useEffect, useId, useRef, useState } from "react";
import { SERVICE_ICONS } from "@/components/icons";
import { CTA_MICROCOPY, SITE } from "@/config/site";
import { quoteServices, type ServiceId } from "@/content/services";
import {
  FALLBACK_MESSAGE,
  TIMES,
  stepFourSchema,
  stepOneSchema,
  stepThreeSchema,
  stepTwoSchema,
  submitQuote,
  type QuoteResult,
} from "@/lib/quote";
import { cn } from "@/lib/cn";

type When = (typeof TIMES)[number]["id"];

type FormState = {
  service: ServiceId | "";
  when: When | "";
  postcode: string;
  name: string;
  mobile: string;
  note: string;
};

const EMPTY: FormState = { service: "", when: "", postcode: "", name: "", mobile: "", note: "" };

type Errors = Partial<Record<keyof FormState, string>>;
type Status = "idle" | "loading" | "success" | "error";

const STEP_TITLES = ["What do you need?", "How soon?", "Where are you?", "How do we reach you?"] as const;
const STEPS = STEP_TITLES.length;
const LAST = STEPS - 1;
/** Pause so the tapped option is seen before the next page slides in. */
const ADVANCE_MS = 260;

const inputClass =
  "block min-h-14 w-full rounded-xl border-2 bg-white px-4 text-lg font-medium text-text placeholder:text-text/45 focus:border-support";

const optionBase =
  "relative flex w-full cursor-pointer text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-support";

/**
 * The ONE quote form, shown as a popup. The two call-to-action buttons (hero and
 * final block) open it. It is a short multi-page flow: on the tap pages, one
 * click picks an answer and the next page opens by itself. The text pages
 * continue with Enter or the button.
 *
 * DEMO MODE: validated with Zod, but nothing is ever sent anywhere.
 */
export function QuoteForm() {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const advanceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const uid = useId();

  const [form, setForm] = useState<FormState>(EMPTY);
  const [step, setStep] = useState(0);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [result, setResult] = useState<QuoteResult | null>(null);

  const clearTimer = () => {
    if (advanceTimer.current) clearTimeout(advanceTimer.current);
    advanceTimer.current = null;
  };

  const reset = useCallback(() => {
    if (advanceTimer.current) clearTimeout(advanceTimer.current);
    advanceTimer.current = null;
    setForm(EMPTY);
    setStep(0);
    setErrors({});
    setStatus("idle");
    setResult(null);
  }, []);

  const open = useCallback(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (status === "success") reset();
    setErrors({});
    if (!dialog.open) dialog.showModal();
  }, [status, reset]);

  const close = useCallback(() => {
    dialogRef.current?.close();
  }, []);

  // The CTA buttons open this popup. No links, no hash, no page jump.
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const target = (e.target as HTMLElement | null)?.closest<HTMLElement>("[data-quote-open]");
      if (!target) return;
      e.preventDefault();
      open();
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, [open]);

  useEffect(() => clearTimer, []);

  const onDialogClose = () => {
    clearTimer();
    if (status === "success") reset();
  };

  // Move focus to the page heading whenever the page or status changes.
  useEffect(() => {
    if (dialogRef.current?.open) headingRef.current?.focus();
  }, [step, status]);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => (e[key] ? { ...e, [key]: undefined } : e));
  };

  /** One tap: store the answer, then open the next page by itself. */
  const choose = <K extends "service" | "when">(key: K, value: FormState[K]) => {
    if (advanceTimer.current) return; // ignore double taps while advancing
    set(key, value);
    advanceTimer.current = setTimeout(() => {
      advanceTimer.current = null;
      setStep((s) => Math.min(s + 1, LAST));
    }, ADVANCE_MS);
  };

  const validate = (s: number): Errors => {
    const schema = [stepOneSchema, stepTwoSchema, stepThreeSchema, stepFourSchema][s];
    const parsed = schema.safeParse({ ...form, note: form.note || undefined });
    if (parsed.success) return {};
    const out: Errors = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path[0] as keyof FormState;
      if (key && !out[key]) out[key] = issue.message;
    }
    return out;
  };

  const focusFirstError = (errs: Errors) => {
    const first = Object.keys(errs)[0];
    if (!first) return;
    requestAnimationFrame(() => {
      dialogRef.current?.querySelector<HTMLElement>(`[name="${first}"]`)?.focus();
    });
  };

  const next = () => {
    const errs = validate(step);
    setErrors(errs);
    if (Object.keys(errs).length) {
      focusFirstError(errs);
      return;
    }
    setStep((s) => Math.min(s + 1, LAST));
  };

  const back = () => {
    clearTimer();
    setErrors({});
    setStep((s) => Math.max(s - 1, 0));
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step < LAST) {
      // Tap pages advance on tap; Enter on a text page continues.
      if (step >= 2) next();
      return;
    }
    const errs = validate(LAST);
    setErrors(errs);
    if (Object.keys(errs).length) {
      focusFirstError(errs);
      return;
    }
    setStatus("loading");
    const emergency = form.service === "emergency" || form.when === "emergency";
    const res = await submitQuote({ ...form, emergency, note: form.note || undefined });
    setResult(res);
    setStatus(res.ok ? "success" : "error");
  };

  const progress = status === "success" ? 100 : ((step + 1) / STEPS) * 100;
  const showForm = status !== "success";
  const isTapPage = step < 2;

  return (
    <dialog
      ref={dialogRef}
      id="quote-dialog"
      aria-labelledby={`${uid}-title`}
      onClose={onDialogClose}
      onClick={(e) => {
        if (e.target === dialogRef.current) close();
      }}
      className="fixed inset-0 m-0 h-full max-h-none w-full max-w-none overflow-hidden border-0 bg-transparent p-0 text-text backdrop:bg-brand/75 backdrop:backdrop-blur-sm sm:m-auto sm:h-fit sm:max-h-[min(92dvh,50rem)] sm:max-w-xl sm:rounded-3xl"
    >
      <div className="flex h-full max-h-[inherit] flex-col bg-white sm:rounded-3xl">
        {/* Header + progress */}
        <div className="shrink-0 border-b border-brand/10 px-5 pb-4 pt-5 sm:px-8 sm:pt-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-extrabold uppercase tracking-[0.12em] text-text/65">
                {status === "success" ? "All done" : `Step ${step + 1} of ${STEPS}`}
              </p>
              <h2
                id={`${uid}-title`}
                ref={headingRef}
                tabIndex={-1}
                className="mt-1 text-2xl outline-none sm:text-[1.75rem]"
              >
                {status === "success" ? "Thanks, we've got it" : STEP_TITLES[step]}
              </h2>
            </div>
            <button
              type="button"
              onClick={close}
              aria-label="Close quote form"
              className="-mr-2 -mt-1 grid size-12 shrink-0 place-items-center rounded-xl text-brand transition-colors hover:bg-brand/5"
            >
              <X aria-hidden className="size-6" strokeWidth={2.5} />
            </button>
          </div>
          <div
            role="progressbar"
            aria-label="Quote form progress"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(progress)}
            className="mt-4 h-2 overflow-hidden rounded-full bg-brand/10"
          >
            <div
              className="h-full rounded-full bg-support transition-[width] duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {showForm ? (
          <form noValidate onSubmit={onSubmit} className="flex min-h-0 flex-1 flex-col">
            <div className="flex-1 overflow-y-auto px-5 py-6 sm:px-8">
              <div key={step} className="step-in">
                {/* PAGE 1: tap a job, next page opens */}
                {step === 0 && (
                  <div role="group" aria-labelledby={`${uid}-title`}>
                    <p className="mb-3 text-[1.0625rem] font-bold text-text/80">Tap what fits best.</p>
                    <div className="grid grid-cols-2 gap-3">
                      {quoteServices.map((s, i) => {
                        const Icon = SERVICE_ICONS[s.icon];
                        const selected = form.service === s.id;
                        return (
                          <button
                            key={s.id}
                            type="button"
                            name={i === 0 ? "service" : undefined}
                            aria-pressed={selected}
                            onClick={() => choose("service", s.id)}
                            className={cn(
                              optionBase,
                              "min-h-[5.5rem] flex-col justify-center gap-1.5 rounded-2xl border-2 p-3.5",
                              selected
                                ? "border-support bg-support/10"
                                : "border-brand/15 bg-white hover:border-support/60",
                              i === quoteServices.length - 1 && "col-span-2 sm:col-span-1",
                            )}
                          >
                            <span className="flex items-center gap-2.5">
                              <Icon
                                aria-hidden
                                className={cn("size-6 shrink-0", selected ? "text-support" : "text-brand")}
                                strokeWidth={2}
                              />
                              <span className="font-extrabold leading-tight text-brand">{s.label}</span>
                            </span>
                            <span className="text-sm leading-snug text-text/65">{s.hint}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* PAGE 2: tap how soon, next page opens */}
                {step === 1 && (
                  <div role="group" aria-labelledby={`${uid}-title`}>
                    <p className="mb-3 text-[1.0625rem] font-bold text-text/80">Tap when you need us.</p>
                    <div className="grid gap-3">
                      {TIMES.map((t) => {
                        const selected = form.when === t.id;
                        return (
                          <button
                            key={t.id}
                            type="button"
                            aria-pressed={selected}
                            onClick={() => choose("when", t.id)}
                            className={cn(
                              optionBase,
                              "min-h-16 items-center justify-between gap-4 rounded-2xl border-2 px-4 py-3",
                              selected
                                ? "border-support bg-support/10"
                                : "border-brand/15 bg-white hover:border-support/60",
                            )}
                          >
                            <span>
                              <span className="block font-extrabold text-brand">{t.label}</span>
                              <span className="block text-sm leading-snug text-text/65">{t.hint}</span>
                            </span>
                            <ArrowRight aria-hidden className="size-5 shrink-0 text-support" strokeWidth={2.75} />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* PAGE 3: postcode */}
                {step === 2 && (
                  <div>
                    <label htmlFor={`${uid}-postcode`} className="mb-2 block font-extrabold text-brand">
                      Your postcode
                    </label>
                    <input
                      id={`${uid}-postcode`}
                      name="postcode"
                      type="text"
                      inputMode="text"
                      autoComplete="postal-code"
                      autoCapitalize="characters"
                      placeholder="e.g. NG1 1AA"
                      value={form.postcode}
                      onChange={(e) => set("postcode", e.target.value)}
                      aria-invalid={errors.postcode ? true : undefined}
                      aria-describedby={errors.postcode ? `${uid}-postcode-err` : `${uid}-postcode-hint`}
                      className={cn(inputClass, errors.postcode ? "border-danger" : "border-brand/20")}
                    />
                    {!errors.postcode && (
                      <p id={`${uid}-postcode-hint`} className="mt-2 text-[0.9375rem] text-text/65">
                        We cover {SITE.areas.postcodes[0]}–{SITE.areas.postcodes[SITE.areas.postcodes.length - 1]},{" "}
                        {SITE.areas.towns.slice(0, -1).join(", ")} and {SITE.areas.towns.slice(-1)}.
                      </p>
                    )}
                    <FieldError id={`${uid}-postcode-err`} message={errors.postcode} />
                  </div>
                )}

                {/* PAGE 4: contact details */}
                {step === 3 && (
                  <div className="space-y-5">
                    <div>
                      <label htmlFor={`${uid}-name`} className="mb-2 block font-extrabold text-brand">
                        Your name
                      </label>
                      <input
                        id={`${uid}-name`}
                        name="name"
                        type="text"
                        autoComplete="given-name"
                        value={form.name}
                        onChange={(e) => set("name", e.target.value)}
                        aria-invalid={errors.name ? true : undefined}
                        aria-describedby={errors.name ? `${uid}-name-err` : undefined}
                        className={cn(inputClass, errors.name ? "border-danger" : "border-brand/20")}
                      />
                      <FieldError id={`${uid}-name-err`} message={errors.name} />
                    </div>

                    <div>
                      <label htmlFor={`${uid}-mobile`} className="mb-2 block font-extrabold text-brand">
                        Mobile number
                      </label>
                      <input
                        id={`${uid}-mobile`}
                        name="mobile"
                        type="tel"
                        inputMode="tel"
                        autoComplete="tel"
                        placeholder="e.g. 07700 900123"
                        value={form.mobile}
                        onChange={(e) => set("mobile", e.target.value)}
                        aria-invalid={errors.mobile ? true : undefined}
                        aria-describedby={errors.mobile ? `${uid}-mobile-err` : `${uid}-mobile-hint`}
                        className={cn(inputClass, errors.mobile ? "border-danger" : "border-brand/20")}
                      />
                      {!errors.mobile && (
                        <p id={`${uid}-mobile-hint`} className="mt-2 text-[0.9375rem] text-text/65">
                          We&apos;ll text you your fixed price. No marketing, no sharing.
                        </p>
                      )}
                      <FieldError id={`${uid}-mobile-err`} message={errors.mobile} />
                    </div>

                    <div>
                      <label htmlFor={`${uid}-note`} className="mb-2 block font-extrabold text-brand">
                        Anything we should know?{" "}
                        <span className="font-medium text-text/65">(optional)</span>
                      </label>
                      <input
                        id={`${uid}-note`}
                        name="note"
                        type="text"
                        placeholder="e.g. Kitchen tap drips all night"
                        value={form.note}
                        onChange={(e) => set("note", e.target.value)}
                        aria-invalid={errors.note ? true : undefined}
                        aria-describedby={errors.note ? `${uid}-note-err` : undefined}
                        className={cn(inputClass, errors.note ? "border-danger" : "border-brand/20")}
                      />
                      <FieldError id={`${uid}-note-err`} message={errors.note} />
                    </div>

                    {status === "error" && result && !result.ok ? (
                      <div
                        role="alert"
                        className="flex items-start gap-3 rounded-xl border-2 border-danger/40 bg-danger/5 p-4 text-danger"
                      >
                        <CircleAlert aria-hidden className="mt-0.5 size-5 shrink-0" strokeWidth={2.5} />
                        <p className="font-bold">
                          {result.message || FALLBACK_MESSAGE}{" "}
                          <a href={`tel:${SITE.phone.tel}`} className="underline underline-offset-4">
                            Tap to call
                          </a>
                          .
                        </p>
                      </div>
                    ) : null}
                  </div>
                )}
              </div>
            </div>

            {/* Footer buttons */}
            <div className="shrink-0 border-t border-brand/10 bg-white px-5 pb-5 pt-4 sm:rounded-b-3xl sm:px-8 sm:pb-6">
              <div className="flex items-center gap-3">
                {step > 0 ? (
                  <button
                    type="button"
                    onClick={back}
                    disabled={status === "loading"}
                    className="inline-flex min-h-14 items-center gap-2 rounded-xl border-2 border-brand/20 px-5 text-lg font-extrabold text-brand transition-colors hover:border-support disabled:opacity-60"
                  >
                    <ArrowLeft aria-hidden className="size-5" strokeWidth={2.75} />
                    Back
                  </button>
                ) : null}

                {isTapPage ? (
                  <p className="flex-1 text-center text-[0.9375rem] font-bold text-text/65">
                    Tap an option and the next page opens.
                  </p>
                ) : step < LAST ? (
                  <button
                    type="submit"
                    className="inline-flex min-h-14 flex-1 items-center justify-center gap-2 rounded-xl bg-brand px-6 text-lg font-extrabold text-white transition-colors hover:bg-brand/90"
                  >
                    Continue
                    <ArrowRight aria-hidden className="size-5" strokeWidth={2.75} />
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={status === "loading"}
                    aria-busy={status === "loading"}
                    className="inline-flex min-h-14 flex-1 items-center justify-center gap-2 rounded-xl bg-brand px-6 text-lg font-extrabold text-white transition-colors hover:bg-brand/90 disabled:opacity-80"
                  >
                    {status === "loading" ? (
                      <>
                        <LoaderCircle aria-hidden className="size-5 animate-spin" strokeWidth={3} />
                        Sending…
                      </>
                    ) : (
                      <>
                        Send my request
                        <ArrowRight aria-hidden className="size-5" strokeWidth={2.75} />
                      </>
                    )}
                  </button>
                )}
              </div>
              <p className="mt-3 text-center text-[0.9375rem] leading-snug text-text/65">{CTA_MICROCOPY}</p>
            </div>
          </form>
        ) : (
          <div className="flex-1 overflow-y-auto px-5 py-8 text-center sm:px-8" role="status" aria-live="polite">
            <span className="mx-auto grid size-16 place-items-center rounded-full bg-support/10 text-support">
              <CircleCheck aria-hidden className="size-9" strokeWidth={2} />
            </span>
            {result && result.ok ? (
              <>
                <p className="mt-5 text-xl font-extrabold text-brand">Thanks, {result.name.split(" ")[0]}.</p>
                <p className="mx-auto mt-2 max-w-sm text-lg text-text/85">
                  {result.replyCopy} Your fixed price comes in writing, with no obligation.
                </p>
                {result.emergency ? (
                  <p className="mx-auto mt-3 max-w-sm text-text/75">
                    Water still coming in? Turn off your stopcock if you can, then call{" "}
                    <a href={`tel:${SITE.phone.tel}`} className="text-link">
                      {SITE.phone.display}
                    </a>
                    .
                  </p>
                ) : null}
                <p className="mx-auto mt-6 inline-flex rounded-xl bg-brand/5 px-4 py-2.5 text-[0.9375rem] font-extrabold text-brand">
                  Demo only: no data was sent.
                </p>
                <div className="mt-6">
                  <button
                    type="button"
                    onClick={close}
                    className="inline-flex min-h-14 items-center justify-center rounded-xl border-2 border-brand/20 px-8 text-lg font-extrabold text-brand transition-colors hover:border-support"
                  >
                    Close
                  </button>
                </div>
              </>
            ) : null}
          </div>
        )}
      </div>
    </dialog>
  );
}

function FieldError({ id, message }: { id: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={id} role="alert" className="mt-2 flex items-start gap-2 font-bold text-danger">
      <CircleAlert aria-hidden className="mt-0.5 size-[18px] shrink-0" strokeWidth={2.5} />
      {message}
    </p>
  );
}
