"use client";

import { Menu, Phone, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { NAV_LINKS, SITE } from "@/config/site";

/** Hamburger menu for screens below `lg`. Esc closes; focus returns to the button. */
export function MobileMenu() {
  const [open, setOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        buttonRef.current?.focus();
      }
      if (e.key === "Tab" && panelRef.current) {
        const focusables = panelRef.current.querySelectorAll<HTMLElement>("a[href], button");
        const all = [buttonRef.current, ...Array.from(focusables)].filter(Boolean) as HTMLElement[];
        const first = all[0];
        const last = all[all.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    const onClickAway = (e: MouseEvent) => {
      const t = e.target as Node;
      if (!panelRef.current?.contains(t) && !buttonRef.current?.contains(t)) setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClickAway);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClickAway);
    };
  }, [open]);

  return (
    <div className="lg:hidden">
      <button
        ref={buttonRef}
        type="button"
        aria-expanded={open}
        aria-controls="mobile-menu"
        aria-label={open ? "Close menu" : "Open menu"}
        onClick={() => setOpen((v) => !v)}
        className="grid size-12 place-items-center rounded-xl border-2 border-brand/15 text-brand transition-colors hover:border-support"
      >
        {open ? <X className="size-6" strokeWidth={2.5} /> : <Menu className="size-6" strokeWidth={2.5} />}
      </button>

      <div
        id="mobile-menu"
        ref={panelRef}
        hidden={!open}
        className="absolute inset-x-0 top-full border-b border-brand/10 bg-white shadow-lift"
      >
        <nav aria-label="Mobile" className="mx-auto max-w-6xl px-5 pb-6 pt-3 sm:px-8">
          <ul>
            {NAV_LINKS.map((l) => (
              <li key={l.href} className="border-b border-brand/10">
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="flex min-h-14 items-center text-lg font-extrabold text-brand"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href={`tel:${SITE.phone.tel}`}
            className="mt-5 flex min-h-12 items-center justify-center gap-2 font-extrabold text-brand underline decoration-support decoration-2 underline-offset-4"
          >
            <Phone aria-hidden className="size-4 text-support" strokeWidth={2.5} />
            Emergency? Call {SITE.phone.display}
          </a>
        </nav>
      </div>
    </div>
  );
}
