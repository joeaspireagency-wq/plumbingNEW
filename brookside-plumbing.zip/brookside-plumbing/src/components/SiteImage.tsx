import Image from "next/image";
import { Droplets } from "lucide-react";
import type { SiteImageData } from "@/content/images";
import { cn } from "@/lib/cn";

type Props = {
  image: SiteImageData;
  /** Override the wrapper aspect ratio, e.g. "aspect-[4/3]". Default: the image's own ratio. */
  aspectClass?: string;
  /** Mark purely decorative images (renders empty alt). */
  decorative?: boolean;
  className?: string;
  imgClassName?: string;
};

/**
 * next/image with a stable aspect ratio (no layout shift) and a branded
 * gradient + icon fallback sitting behind the picture, so a failed load never
 * leaves a blank or broken box. `priority` comes from the image data and is
 * set on the hero image only.
 */
export function SiteImage({ image, aspectClass, decorative, className, imgClassName }: Props) {
  return (
    <div
      className={cn("relative overflow-hidden bg-brand", aspectClass, className)}
      style={aspectClass ? undefined : { aspectRatio: image.aspect }}
    >
      <div
        aria-hidden="true"
        className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-brand to-support"
      >
        <Droplets className="size-14 text-white/40" strokeWidth={1.5} />
      </div>
      <Image
        src={image.src}
        alt={decorative ? "" : image.alt}
        fill
        sizes={image.sizes}
        quality={82}
        priority={image.priority}
        fetchPriority={image.priority ? "high" : undefined}
        loading={image.priority ? undefined : "lazy"}
        className={cn("object-cover text-transparent", imgClassName)}
        style={image.focal ? { objectPosition: image.focal } : undefined}
        draggable={false}
      />
    </div>
  );
}
