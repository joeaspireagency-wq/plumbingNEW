import { SITE } from "@/config/site";

/** Simple chat-bubble-with-handset mark (own drawing, 24px grid). */
function ChatIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className={className} fill="none">
      <path
        d="M12 2.8a9.2 9.2 0 0 0-7.9 13.9L2.9 21.1l4.5-1.2A9.2 9.2 0 1 0 12 2.8Z"
        stroke="currentColor"
        strokeWidth="1.9"
        strokeLinejoin="round"
      />
      <path
        transform="translate(6.6 6.6) scale(.45)"
        fill="currentColor"
        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"
      />
    </svg>
  );
}

const href = `https://wa.me/${SITE.whatsapp.number}?text=${encodeURIComponent(SITE.whatsapp.message)}`;

const circle =
  "grid size-14 shrink-0 place-items-center rounded-full bg-whatsapp text-white shadow-lift ring-4 ring-white/90 transition-transform";

/**
 * Floating WhatsApp contact.
 * Phone: green "Message us on WhatsApp" pill plus round icon along the bottom.
 * Laptop: round icon in the bottom-right corner with a "Contact us" label beside it.
 */
export function WhatsAppFloat() {
  return (
    <>
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 flex justify-center px-4 pb-[max(1rem,env(safe-area-inset-bottom))] md:hidden">
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Message us on WhatsApp"
          className="whatsapp-float pointer-events-auto flex items-center gap-2.5 min-[380px]:gap-3"
        >
          <span className="inline-flex min-h-14 items-center whitespace-nowrap rounded-2xl bg-whatsapp px-4 text-[0.9375rem] font-extrabold text-white shadow-lift ring-4 ring-white/90 min-[380px]:px-6 min-[380px]:text-[1.0625rem]">
            Message us on WhatsApp
          </span>
          <span className={circle}>
            <ChatIcon className="size-8" />
          </span>
        </a>
      </div>

      <div className="pointer-events-none fixed bottom-6 right-6 z-30 hidden md:block">
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Contact us on WhatsApp"
          className="whatsapp-float pointer-events-auto flex items-center gap-3"
        >
          <span className="rounded-full bg-white px-5 py-2.5 text-[1.0625rem] font-extrabold text-text shadow-lift ring-1 ring-brand/10">
            Contact us
          </span>
          <span className={circle}>
            <ChatIcon className="size-8" />
          </span>
        </a>
      </div>
    </>
  );
}
