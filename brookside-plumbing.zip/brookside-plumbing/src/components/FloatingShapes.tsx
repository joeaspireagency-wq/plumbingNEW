import type { CSSProperties } from "react";
import { cn } from "@/lib/cn";

type Variant = "dark" | "light";

type Shape = {
  kind: "disc" | "ring" | "pipe" | "line";
  size: number; // px (width for pipe/line)
  top: string;
  left: string;
  dx: number;
  dy: number;
  rot?: number;
  dur: number; // 20-45s
  delay: number; // negative = already part-way through
  tone: 0 | 1 | 2;
};

/** 12 shapes; the first 6 show on mobile, all 12 from md up. Never orange. */
const SHAPES: Shape[] = [
  { kind: "disc", size: 340, top: "-8%", left: "-6%", dx: 40, dy: 30, dur: 38, delay: -4, tone: 0 },
  { kind: "ring", size: 220, top: "58%", left: "80%", dx: -30, dy: -36, dur: 31, delay: -12, tone: 1 },
  { kind: "pipe", size: 360, top: "8%", left: "58%", dx: -40, dy: 24, rot: 6, dur: 42, delay: -9, tone: 0 },
  { kind: "disc", size: 120, top: "72%", left: "8%", dx: 26, dy: -28, dur: 27, delay: -17, tone: 1 },
  { kind: "line", size: 280, top: "34%", left: "-4%", dx: 50, dy: 10, rot: -4, dur: 36, delay: -22, tone: 2 },
  { kind: "ring", size: 90, top: "14%", left: "88%", dx: -18, dy: 40, dur: 24, delay: -6, tone: 0 },
  { kind: "disc", size: 70, top: "46%", left: "46%", dx: 30, dy: -24, dur: 29, delay: -14, tone: 2 },
  { kind: "pipe", size: 300, top: "78%", left: "34%", dx: 36, dy: -20, rot: -5, dur: 44, delay: -3, tone: 1 },
  { kind: "ring", size: 160, top: "-4%", left: "30%", dx: -26, dy: 32, dur: 33, delay: -19, tone: 2 },
  { kind: "line", size: 220, top: "64%", left: "66%", dx: -44, dy: -8, rot: 5, dur: 40, delay: -11, tone: 0 },
  { kind: "disc", size: 180, top: "30%", left: "92%", dx: -34, dy: 22, dur: 35, delay: -25, tone: 2 },
  { kind: "disc", size: 56, top: "88%", left: "58%", dx: 20, dy: -30, dur: 22, delay: -8, tone: 1 },
];

/* Literal class strings so Tailwind can see them. */
const FILL = {
  dark: ["bg-white/[0.07]", "bg-support/[0.14]", "bg-white/[0.06]"],
  light: ["bg-support/[0.07]", "bg-brand/[0.05]", "bg-support/[0.10]"],
} as const;
const RING = {
  dark: ["border-white/[0.14]", "border-support/[0.30]", "border-white/[0.10]"],
  light: ["border-support/[0.16]", "border-brand/[0.10]", "border-support/[0.12]"],
} as const;
const STROKE = {
  dark: ["stroke-white/[0.15]", "stroke-support/[0.30]", "stroke-white/[0.10]"],
  light: ["stroke-support/[0.22]", "stroke-brand/[0.10]", "stroke-support/[0.16]"],
} as const;

function style(s: Shape): CSSProperties {
  return {
    top: s.top,
    left: s.left,
    "--dx": `${s.dx}px`,
    "--dy": `${s.dy}px`,
    "--rot": `${s.rot ?? 0}deg`,
    "--dur": `${s.dur}s`,
    "--delay": `${s.delay}s`,
  } as CSSProperties;
}

/**
 * Decorative drifting circles and pipe-like lines. Pure CSS keyframes
 * (transform + opacity only), independent of scrolling. Paused when off-screen
 * via the [data-observe] hook, and static under prefers-reduced-motion.
 */
export function FloatingShapes({ variant = "dark" }: { variant?: Variant }) {
  return (
    <div
      aria-hidden="true"
      data-observe
      className="pointer-events-none absolute inset-0 -z-10 overflow-hidden"
    >
      {SHAPES.map((s, i) => {
        const hideOnMobile = i >= 6 ? "hidden md:block" : "";
        if (s.kind === "disc") {
          return (
            <span
              key={i}
              className={cn("shape rounded-full", FILL[variant][s.tone], hideOnMobile)}
              style={{ ...style(s), width: s.size, height: s.size }}
            />
          );
        }
        if (s.kind === "ring") {
          return (
            <span
              key={i}
              className={cn("shape rounded-full border-2", RING[variant][s.tone], hideOnMobile)}
              style={{ ...style(s), width: s.size, height: s.size }}
            />
          );
        }
        if (s.kind === "line") {
          return (
            <svg
              key={i}
              className={cn("shape", hideOnMobile)}
              style={{ ...style(s), width: s.size, height: 24 }}
              viewBox="0 0 280 24"
              fill="none"
            >
              <path
                d="M2 12 C 60 -2, 100 26, 160 12 S 246 -2, 278 12"
                className={STROKE[variant][s.tone]}
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          );
        }
        // pipe: a thin, soft-cornered pipe run with a joint dot
        return (
          <svg
            key={i}
            className={cn("shape", hideOnMobile)}
            style={{ ...style(s), width: s.size, height: s.size * 0.5 }}
            viewBox="0 0 360 180"
            fill="none"
          >
            <path
              d="M4 150 H110 Q140 150 140 120 V70 Q140 40 170 40 H356"
              className={STROKE[variant][s.tone]}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="140" cy="95" r="6" className={STROKE[variant][s.tone]} strokeWidth="2" />
          </svg>
        );
      })}
    </div>
  );
}
