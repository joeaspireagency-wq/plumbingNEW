import { Mail, Phone, ShieldCheck } from "lucide-react";
import { Container } from "@/components/Container";
import { Wordmark } from "@/components/Header";
import { FloatingShapes } from "@/components/FloatingShapes";
import { LEGAL_LINKS, SITE } from "@/config/site";
import { quoteServices } from "@/content/services";

const linkClass =
  "inline-flex min-h-12 items-center text-white/85 underline-offset-4 hover:text-white hover:underline";

export function Footer() {
  return (
    <footer className="relative isolate overflow-hidden border-t border-white/10 bg-brand text-white">
      <FloatingShapes variant="dark" />
      <Container className="pb-32 pt-14 md:pb-24">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          <div>
            <Wordmark light />
            <p className="mt-4 max-w-xs text-white/80">
              Friendly, plain-spoken Nottingham plumbing. A fixed price in writing before we start.
            </p>
            <ul className="mt-3 space-y-0.5">
              <li>
                <a href={`tel:${SITE.phone.tel}`} className={`${linkClass} gap-2 font-extrabold text-white`}>
                  <Phone aria-hidden className="size-4 text-white/70" strokeWidth={2.5} />
                  {SITE.phone.display}
                </a>
              </li>
              <li>
                <a href={`mailto:${SITE.email}`} className={`${linkClass} gap-2 break-all`}>
                  <Mail aria-hidden className="size-4 shrink-0 text-white/70" strokeWidth={2.5} />
                  {SITE.email}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-base uppercase tracking-[0.12em] text-white/70">Services</h2>
            <ul className="mt-3">
              {quoteServices
                .filter((s) => s.id !== "something-else")
                .map((s) => (
                  <li key={s.id}>
                    <a href="#services" className={linkClass}>
                      {s.label}
                    </a>
                  </li>
                ))}
            </ul>
          </div>

          <div>
            <h2 className="text-base uppercase tracking-[0.12em] text-white/70">Areas covered</h2>
            <p className="mt-3 text-white/85">
              {SITE.areas.postcodes[0]}–{SITE.areas.postcodes[SITE.areas.postcodes.length - 1]}
            </p>
            <ul className="mt-1">
              {SITE.areas.towns.map((t) => (
                <li key={t} className="py-1 text-white/85">
                  {t}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="text-base uppercase tracking-[0.12em] text-white/70">Hours and trust</h2>
            <p className="mt-3 text-white/85">{SITE.hours.summary}</p>
            <p className="font-extrabold text-white">{SITE.hours.emergency}</p>
            <ul className="mt-4 space-y-2">
              {SITE.accreditations.map((a) => (
                <li key={a.name} className="flex items-center gap-2.5 text-white/90">
                  <ShieldCheck aria-hidden className="size-5 shrink-0 text-white/70" strokeWidth={2} />
                  {a.name}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[0.9375rem] leading-snug text-white/75">
              {SITE.insurance}. {SITE.guarantee}.
            </p>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-white/15 pt-6 text-[0.9375rem] text-white/75 md:flex-row md:items-center md:justify-between">
          <p>© 2026 Brookside Plumbing</p>
          <ul className="flex flex-wrap items-center gap-x-5">
            {LEGAL_LINKS.map((l) => (
              <li key={l.label}>
                <a href={l.href} data-legal className={linkClass}>
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <p className="font-extrabold text-white/90">Prototype with sample content</p>
        </div>
      </Container>
    </footer>
  );
}
