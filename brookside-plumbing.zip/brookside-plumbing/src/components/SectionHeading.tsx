import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

type Props = {
  id?: string;
  eyebrow?: string;
  title: string;
  lead?: ReactNode;
  align?: "left" | "center";
  tone?: "light" | "dark";
  className?: string;
};

export function SectionHeading({
  id,
  eyebrow,
  title,
  lead,
  align = "left",
  tone = "light",
  className,
}: Props) {
  const dark = tone === "dark";
  return (
    <div
      className={cn(
        "max-w-2xl",
        align === "center" && "mx-auto text-center",
        className,
      )}
    >
      {eyebrow ? (
        <p
          className={cn(
            "mb-3 flex items-center gap-3 text-sm font-extrabold uppercase tracking-[0.14em]",
            align === "center" && "justify-center",
            dark ? "text-white/80" : "text-brand/75",
          )}
        >
          <span aria-hidden className="h-0.5 w-8 rounded-full bg-support" />
          {eyebrow}
        </p>
      ) : null}
      <h2
        id={id}
        className={cn(
          "text-[clamp(1.875rem,4.6vw,2.75rem)]",
          dark && "text-white",
        )}
      >
        {title}
      </h2>
      {lead ? (
        <p
          className={cn(
            "mt-4 text-lg leading-relaxed",
            dark ? "text-white/85" : "text-text/75",
          )}
        >
          {lead}
        </p>
      ) : null}
    </div>
  );
}
