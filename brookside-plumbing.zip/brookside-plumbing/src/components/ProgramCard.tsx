import { Check, Clock } from "lucide-react";
import { SERVICE_ICONS } from "@/components/icons";
import { SiteImage } from "@/components/SiteImage";
import { getImage } from "@/content/images";
import type { Program } from "@/content/services";

export function ProgramCard({ program }: { program: Program }) {
  const Icon = SERVICE_ICONS[program.icon];
  return (
    <article className="relative flex h-full flex-col overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-brand/5">
      <div className="relative">
        <SiteImage image={getImage(program.imageId)} aspectClass="aspect-[16/10]" decorative />
        {program.popular ? (
          <span className="absolute left-4 top-4 rounded-full bg-brand px-3.5 py-1.5 text-sm font-extrabold text-white shadow-card">
            Most popular
          </span>
        ) : null}
      </div>

      <div className="flex flex-1 flex-col p-6">
        <div className="flex items-center gap-3 xl:min-h-[3.5rem]">
          <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-support/10 text-support">
            <Icon aria-hidden className="size-6" strokeWidth={2} />
          </span>
          <h3 className="text-xl">{program.name}</h3>
        </div>

        <p className="mt-4 text-[1.0625rem] leading-snug text-text/80 xl:min-h-[6.25rem]">{program.benefit}</p>

        <div className="mt-5 flex flex-wrap items-baseline gap-x-2 gap-y-1 border-y border-brand/10 py-4">
          <span className="text-sm font-bold uppercase tracking-wide text-text/60">From</span>
          <span className="text-3xl font-extrabold tracking-tight text-brand">
            {program.priceFrom}
          </span>
          {program.priceSuffix ? (
            <span className="text-[0.9375rem] font-bold text-text/70">{program.priceSuffix}</span>
          ) : null}
        </div>

        <p className="mt-3 flex items-start gap-2 text-[0.9375rem] font-bold text-text/75">
          <Clock aria-hidden className="mt-1 size-4 shrink-0 text-support" strokeWidth={2.25} />
          {program.time}
        </p>

        <ul className="mt-5 space-y-2.5">
          {program.features.map((f) => (
            <li key={f} className="flex items-start gap-2.5 text-[0.9375rem] leading-snug">
              <Check aria-hidden className="mt-0.5 size-5 shrink-0 text-support" strokeWidth={3} />
              <span>{f}</span>
            </li>
          ))}
        </ul>
      </div>
    </article>
  );
}
