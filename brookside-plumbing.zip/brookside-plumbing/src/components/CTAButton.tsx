import { ArrowRight } from "lucide-react";
import { CTA_LABEL } from "@/config/site";
import { cn } from "@/lib/cn";

type Props = {
  size?: "md" | "lg";
  full?: boolean;
  className?: string;
};

/**
 * THE primary call to action. It appears exactly twice on the site: in the hero
 * and in the final block. A real <button> (never a link), so it can never jump
 * the page: QuoteForm listens for clicks on [data-quote-open] and opens the popup.
 */
export function CTAButton({ size = "md", full, className }: Props) {
  return (
    <button
      type="button"
      data-quote-open
      aria-haspopup="dialog"
      className={cn("btn-cta", size === "lg" && "btn-cta-lg", full && "w-full", className)}
    >
      {CTA_LABEL}
      <ArrowRight aria-hidden className="size-5 shrink-0" strokeWidth={2.75} />
    </button>
  );
}
