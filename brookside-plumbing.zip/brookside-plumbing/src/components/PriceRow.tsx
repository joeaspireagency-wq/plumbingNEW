import { Moon } from "lucide-react";
import type { PriceRowData } from "@/content/pricing";
import { cn } from "@/lib/cn";

export function PriceRow({ row }: { row: PriceRowData }) {
  return (
    <tr className={cn("border-t border-brand/10 first:border-t-0", row.popular && "bg-support/[0.06]")}>
      <th scope="row" className="py-2.5 pl-5 pr-3 text-left align-top font-medium sm:py-3 sm:pl-6">
        <span className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
          <span className="text-[1.0625rem] font-extrabold text-brand">{row.label}</span>
          {row.popular ? (
            <span className="rounded-full bg-brand px-3 py-1 text-[0.8125rem] font-extrabold uppercase tracking-wide text-white">
              Most popular
            </span>
          ) : null}
          {row.outOfHours ? (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-support/10 px-3 py-1 text-[0.8125rem] font-extrabold text-brand">
              <Moon aria-hidden className="size-3.5 text-support" strokeWidth={2.5} />
              Out of hours
            </span>
          ) : null}
        </span>
        {row.note ? <span className="mt-1 block text-[0.9375rem] text-text/70">{row.note}</span> : null}
      </th>
      <td className="whitespace-nowrap py-2.5 pl-3 pr-5 text-right align-top sm:py-3 sm:pr-6">
        <span className="text-sm font-bold text-text/60">from </span>
        <span className="text-xl font-extrabold tracking-tight text-brand">{row.from}</span>
        {row.suffix ? (
          <span className="block text-[0.9375rem] font-bold text-text/70">{row.suffix}</span>
        ) : null}
      </td>
    </tr>
  );
}
