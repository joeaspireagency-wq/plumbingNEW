import { BadgeCheck, CalendarDays, PoundSterling } from "lucide-react";
import { BeforeAfter } from "@/components/BeforeAfter";
import { Container } from "@/components/Container";
import { FloatingShapes } from "@/components/FloatingShapes";
import { SectionHeading } from "@/components/SectionHeading";
import { TestimonialSlider } from "@/components/TestimonialSlider";
import { beforeAfter } from "@/content/beforeAfter";
import { getImage } from "@/content/images";
import { reviews } from "@/content/reviews";

/* SAMPLE CONTENT: fictional reviews and demonstration project. Labelled on the page. */
export function SocialProof() {
  return (
    <section id="reviews" aria-labelledby="reviews-title" className="relative isolate overflow-hidden bg-white pb-16 pt-6 sm:pb-20 md:pt-8 lg:pb-24">
      <FloatingShapes variant="light" />
      <Container>
        <div className="grid items-center gap-8 lg:grid-cols-[1.35fr_1fr] lg:gap-12">
          <BeforeAfter
            before={getImage(beforeAfter.beforeImageId)}
            after={getImage(beforeAfter.afterImageId)}
            label={beforeAfter.sliderLabel}
          />
          <article className="rounded-2xl bg-background p-6 shadow-card ring-1 ring-brand/5 sm:p-8">
            <p className="text-sm font-extrabold uppercase tracking-[0.12em] text-text/65">Project</p>
            <h3 className="mt-2 text-2xl">{beforeAfter.title}</h3>
            <ul className="mt-6 space-y-4">
              <li className="flex items-start gap-3.5">
                <CalendarDays aria-hidden className="mt-0.5 size-6 shrink-0 text-support" strokeWidth={2} />
                <p>
                  <span className="block text-sm font-bold text-text/65">Time on site</span>
                  <span className="block font-extrabold text-brand">{beforeAfter.duration}</span>
                </p>
              </li>
              <li className="flex items-start gap-3.5">
                <PoundSterling aria-hidden className="mt-0.5 size-6 shrink-0 text-support" strokeWidth={2} />
                <p>
                  <span className="block text-sm font-bold text-text/65">The price</span>
                  <span className="block font-extrabold text-brand">
                    Quoted {beforeAfter.quoted}, final bill {beforeAfter.finalBill}
                  </span>
                </p>
              </li>
              <li className="flex items-start gap-3.5">
                <BadgeCheck aria-hidden className="mt-0.5 size-6 shrink-0 text-support" strokeWidth={2} />
                <p>
                  <span className="block text-sm font-bold text-text/65">Result</span>
                  <span className="block font-extrabold text-brand">{beforeAfter.result}</span>
                </p>
              </li>
            </ul>
          </article>
        </div>

        <div className="mt-14 sm:mt-16">
          <SectionHeading
            id="reviews-title"
            eyebrow="Reviews"
            title="Real jobs, real neighbours"
            lead="What happens when you ask for a fixed price and get one."
          />
          <div className="mt-8">
            <TestimonialSlider reviews={reviews} />
          </div>
        </div>
      </Container>
    </section>
  );
}
