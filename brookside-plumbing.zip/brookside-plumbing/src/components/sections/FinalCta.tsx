import { CTAButton } from "@/components/CTAButton";
import { Container } from "@/components/Container";
import { FloatingShapes } from "@/components/FloatingShapes";
import { CTA_MICROCOPY, SITE } from "@/config/site";

export function FinalCta() {
  return (
    <section
      id="final-cta"
      aria-labelledby="final-cta-title"
      className="relative isolate overflow-hidden bg-brand text-white"
    >
      <FloatingShapes variant="dark" />
      <Container className="py-16 text-center sm:py-24">
        <h2 id="final-cta-title" className="mx-auto max-w-2xl text-[clamp(2rem,5.4vw,3.25rem)] text-white">
          Leak? Dripping tap? Tell us what&apos;s wrong.
        </h2>
        <p className="mx-auto mt-5 max-w-lg text-xl text-white/90">
          Get a fixed price in writing, usually within the hour.
        </p>
        <div className="mt-8 flex flex-col items-center gap-4">
          <CTAButton size="lg" className="w-full sm:w-auto" />
          <p className="max-w-md text-base leading-snug text-white/80">{CTA_MICROCOPY}</p>
        </div>
        <p className="mt-8 text-lg text-white/90">
          Water coming in right now? Ring our 24/7 line:{" "}
          <a href={`tel:${SITE.phone.tel}`} className="text-link-light whitespace-nowrap">
            {SITE.phone.display}
          </a>
        </p>
      </Container>
    </section>
  );
}
