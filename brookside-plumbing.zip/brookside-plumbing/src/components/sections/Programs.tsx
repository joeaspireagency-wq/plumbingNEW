import { Container } from "@/components/Container";
import { ProgramCard } from "@/components/ProgramCard";
import { SectionHeading } from "@/components/SectionHeading";
import { programs } from "@/content/services";

export function Programs() {
  return (
    <section id="services" aria-labelledby="services-title" className="bg-background pb-16 pt-6 sm:pb-20 md:pt-8 lg:pb-24">
      <Container>
        <SectionHeading
          id="services-title"
          eyebrow="Services"
          title="How we can help"
          lead="Pick the kind of job. We'll send a fixed price, in writing, before we start."
        />

        <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {programs.map((p) => (
            <ProgramCard key={p.id} program={p} />
          ))}
        </div>
      </Container>
    </section>
  );
}
