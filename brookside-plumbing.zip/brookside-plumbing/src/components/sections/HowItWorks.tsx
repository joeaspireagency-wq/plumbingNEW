import { Container } from "@/components/Container";
import { steps } from "@/content/promises";

export function HowItWorks() {
  return (
    <section aria-label="How it works" className="bg-background py-8 sm:py-10 lg:py-12">
      <Container>
        <div id="how-it-works" aria-labelledby="how-title" role="region">
          <p className="mb-1.5 flex items-center gap-3 text-sm font-extrabold uppercase tracking-[0.14em] text-brand/75">
            <span aria-hidden className="h-0.5 w-8 rounded-full bg-support" />
            How it works
          </p>
          <h2 id="how-title" className="text-[clamp(1.5rem,3.4vw,2rem)]">
            Three steps. No chasing.
          </h2>
          <ol className="mt-5 grid gap-3 md:grid-cols-3 md:gap-4">
            {steps.map((s, i) => (
              <li
                key={s.title}
                className="flex items-start gap-3.5 rounded-2xl bg-white p-4 shadow-card ring-1 ring-brand/5"
              >
                <span className="grid size-9 shrink-0 place-items-center rounded-full bg-brand text-lg font-extrabold text-white">
                  {i + 1}
                </span>
                <div>
                  <h3 className="text-lg leading-snug">{s.title}</h3>
                  <p className="mt-1 text-base leading-snug text-text/80">{s.text}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </Container>
    </section>
  );
}
