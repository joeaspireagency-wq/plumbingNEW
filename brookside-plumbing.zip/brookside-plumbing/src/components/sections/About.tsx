import { Container } from "@/components/Container";
import { SectionHeading } from "@/components/SectionHeading";
import { SiteImage } from "@/components/SiteImage";
import { SITE } from "@/config/site";
import { getImage } from "@/content/images";

/* SAMPLE CONTENT: fictional founder profile. */
export function About() {
  return (
    <section id="about" aria-labelledby="about-title" className="bg-white pb-16 pt-6 sm:pb-20 md:pt-8 lg:pb-24">
      <Container>
        <div className="grid items-stretch gap-8 md:grid-cols-[0.8fr_1.2fr] lg:gap-14">
          <div className="relative aspect-[5/4] w-full overflow-hidden rounded-3xl shadow-lift ring-1 ring-brand/10 md:aspect-auto md:min-h-[20rem]">
            <div className="absolute inset-0">
              <SiteImage image={getImage("about-liam")} aspectClass="h-full w-full" />
            </div>
          </div>

          <div className="flex flex-col justify-center">
            <SectionHeading id="about-title" eyebrow="About" title={`Meet ${SITE.owner.firstName}, your plumber`} />
            <div className="mt-6 space-y-4 text-[1.0625rem] leading-relaxed text-text/85">
              <p>
                I did my apprenticeship at a local Nottingham firm and spent eight years learning the
                trade properly. Six years ago I went out on my own with one van and one rule: say what
                it will cost before you start, then charge exactly that.
              </p>
              <p>
                Today it&apos;s me and my apprentice {SITE.owner.apprentice}, two vans, and most of our
                work comes from neighbours telling neighbours. A dripping tap gets the same care as a
                new bathroom.
              </p>
            </div>
            <p className="mt-5 font-extrabold text-brand">
              {SITE.owner.name}, owner · {SITE.owner.yearsExperience} years in the trade
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}
