import { Container } from "@/components/Container";
import { TrustBadge } from "@/components/TrustBadge";
import { trustBadges } from "@/content/promises";

export function TrustBar() {
  return (
    <section aria-label="Why customers trust us" className="bg-white">
      <Container className="py-8 sm:py-10">
        <ul className="grid gap-x-8 gap-y-6 sm:grid-cols-2 lg:grid-cols-4">
          {trustBadges.map((b) => (
            <TrustBadge key={b.title} {...b} />
          ))}
        </ul>
      </Container>
    </section>
  );
}
