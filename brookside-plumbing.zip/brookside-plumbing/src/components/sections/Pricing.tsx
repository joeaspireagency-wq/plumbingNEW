import { Check, CreditCard } from "lucide-react";
import { Container } from "@/components/Container";
import { FloatingShapes } from "@/components/FloatingShapes";
import { PriceRow } from "@/components/PriceRow";
import { SectionHeading } from "@/components/SectionHeading";
import { priceRows, pricingCopy } from "@/content/pricing";

/* SAMPLE CONTENT: all prices are for demonstration only. */
export function Pricing() {
  return (
    <section id="pricing" aria-labelledby="pricing-title" className="relative isolate overflow-hidden bg-white pb-10 pt-4 sm:pb-12 md:pt-6 lg:pb-14">
      <FloatingShapes variant="light" />
      <Container>
        <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr] lg:gap-10">
          <div>
            <SectionHeading
              id="pricing-title"
              eyebrow="Pricing guide"
              title={pricingCopy.title}
              lead={pricingCopy.lead}
            />
            <ul className="mt-5 space-y-3">
              {pricingCopy.principles.map((p) => (
                <li key={p.title} className="flex items-start gap-3.5">
                  <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-full bg-support/10 text-support">
                    <Check aria-hidden className="size-[18px]" strokeWidth={3.5} />
                  </span>
                  <p className="leading-snug">
                    <span className="block font-extrabold text-brand">{p.title}</span>
                    <span className="text-text/75">{p.text}</span>
                  </p>
                </li>
              ))}
            </ul>
            <p className="mt-5 flex items-start gap-3 rounded-2xl bg-background p-3.5 text-[0.9375rem] leading-snug ring-1 ring-brand/5">
              <CreditCard aria-hidden className="mt-0.5 size-5 shrink-0 text-support" strokeWidth={2} />
              <span>{pricingCopy.payment}</span>
            </p>
          </div>

          <div>
            <div className="overflow-hidden rounded-2xl bg-white shadow-lift ring-1 ring-brand/10">
              <table className="w-full border-collapse">
                <caption className="sr-only">Sample plumbing prices, from</caption>
                <thead className="sr-only">
                  <tr>
                    <th scope="col">Job</th>
                    <th scope="col">Price</th>
                  </tr>
                </thead>
                <tbody>
                  {priceRows.map((row) => (
                    <PriceRow key={row.id} row={row} />
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
