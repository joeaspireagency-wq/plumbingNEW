import { Container } from "@/components/Container";
import { FAQ } from "@/components/FAQ";
import { faqs } from "@/content/faqs";

export function FaqSection() {
  return (
    <section id="faq" aria-labelledby="faq-title" className="bg-background py-8 sm:py-10 lg:py-12">
      <Container className="max-w-3xl">
        <div className="text-center">
          <p className="mb-1.5 flex items-center justify-center gap-3 text-sm font-extrabold uppercase tracking-[0.14em] text-brand/75">
            <span aria-hidden className="h-0.5 w-8 rounded-full bg-support" />
            FAQ
          </p>
          <h2 id="faq-title" className="text-[clamp(1.5rem,3.4vw,2rem)]">
            Questions people ask before they call
          </h2>
        </div>
        <div className="mt-5">
          <FAQ items={faqs} />
        </div>
        <p className="mt-4 text-center text-base">
          Still unsure? Message us on WhatsApp, no obligation.
        </p>
      </Container>
    </section>
  );
}
