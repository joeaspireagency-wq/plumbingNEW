import { Award, ShieldCheck, Star } from "lucide-react";
import Image from "next/image";
import { CTAButton } from "@/components/CTAButton";
import { Container } from "@/components/Container";
import { SiteImage } from "@/components/SiteImage";
import { CTA_MICROCOPY, SITE } from "@/config/site";
import { getImage } from "@/content/images";

/* SAMPLE CONTENT: fictional business, owner and figures. */
export function Hero() {
  const bg = getImage("hero-bg");
  return (
    <section id="hero" className="relative isolate overflow-hidden bg-brand text-white">
      {/* Background photo: slightly blurred, then a navy overlay keeps the text easy to read */}
      <div aria-hidden className="absolute inset-0 -z-30 overflow-hidden">
        <Image
          src={bg.src}
          alt=""
          fill
          priority
          fetchPriority="high"
          sizes="100vw"
          quality={80}
          draggable={false}
          className="scale-[1.06] object-cover blur-[3px]"
          style={{ objectPosition: bg.focal }}
        />
      </div>
      <div
        aria-hidden
        className="absolute inset-0 -z-20 bg-brand/75 lg:bg-gradient-to-r lg:from-brand/92 lg:via-brand/62 lg:to-brand/15"
      />
      <Container className="grid items-center gap-10 py-14 sm:py-20 lg:grid-cols-[1.08fr_0.92fr] lg:gap-14 lg:py-28">
        <div>
          <h1 className="text-[clamp(2.25rem,6.2vw,3.875rem)] text-white">
            Nottingham plumber.{" "}
            <span className="text-white/85">Tell us the problem, get a fixed price.</span>
          </h1>
          <p className="mt-5 max-w-xl text-xl leading-snug text-white/90">
            Send your details in 60 seconds. We reply within the hour.
          </p>

          <div className="mt-8 flex flex-col items-stretch gap-4 sm:items-start">
            <CTAButton size="lg" />
            <p className="max-w-md text-base leading-snug text-white/80">{CTA_MICROCOPY}</p>
          </div>

          <ul className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-white/15 pt-6 text-base font-extrabold text-white">
            <li className="inline-flex items-center gap-2">
              <Star aria-hidden className="size-5 fill-support text-support" strokeWidth={1.5} />
              {SITE.rating.score}★ from {SITE.rating.jobs} local jobs
            </li>
            <li className="inline-flex items-center gap-2">
              <ShieldCheck aria-hidden className="size-5 text-support" strokeWidth={2.25} />
              Insured
            </li>
            <li className="inline-flex items-center gap-2">
              <Award aria-hidden className="size-5 text-support" strokeWidth={2.25} />
              5-year guarantee
            </li>
          </ul>
        </div>

        {/* Laptop only: owner card sits low on the right of the photo */}
        <div className="hidden lg:flex lg:items-end lg:justify-end lg:self-stretch">
          <div className="flex items-center gap-4 rounded-2xl bg-white p-4 pr-6 shadow-lift">
            <SiteImage
              image={getImage("about-liam")}
              aspectClass="aspect-square"
              decorative
              className="size-16 shrink-0 rounded-full ring-2 ring-support/30"
            />
            <p className="leading-tight">
              <span className="block text-lg font-extrabold text-brand">
                {SITE.owner.name}, {SITE.owner.yearsExperience} years on the tools
              </span>
              <span className="mt-1 flex items-center gap-1.5 text-[0.9375rem] text-text/75">
                <ShieldCheck aria-hidden className="size-4 text-support" strokeWidth={2.25} />
                WaterSafe registered · Fully insured
              </span>
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}
