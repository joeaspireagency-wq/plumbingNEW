"use client";

import { MoveHorizontal } from "lucide-react";
import { useState } from "react";
import { SiteImage } from "@/components/SiteImage";
import type { SiteImageData } from "@/content/images";

type Props = {
  before: SiteImageData;
  after: SiteImageData;
  label: string;
};

/**
 * Draggable before/after comparison. A real <input type="range"> sits on top,
 * so pointer, touch and keyboard (arrows, Home, End, PageUp/PageDown) all work
 * natively and screen readers announce it as a slider.
 */
export function BeforeAfter({ before, after, label }: Props) {
  const [pos, setPos] = useState(50);

  return (
    <div
      className="relative aspect-[4/3] w-full select-none overflow-hidden rounded-2xl bg-brand shadow-lift ring-1 ring-brand/10 has-[input:focus-visible]:outline-2 has-[input:focus-visible]:outline-offset-4 has-[input:focus-visible]:outline-support"
      style={{ touchAction: "pan-y" }}
    >
      {/* After (full) sits underneath */}
      <div className="absolute inset-0">
        <SiteImage image={after} aspectClass="h-full" />
      </div>

      {/* Before is revealed from the left up to the handle */}
      <div
        className="absolute inset-0"
        style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
        aria-hidden="true"
      >
        <SiteImage image={before} aspectClass="h-full" decorative />
      </div>

      {/* Labels */}
      <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-brand px-3.5 py-1.5 text-sm font-extrabold uppercase tracking-wide text-white shadow-card">
        Before
      </span>
      <span className="pointer-events-none absolute right-3 top-3 rounded-full bg-white px-3.5 py-1.5 text-sm font-extrabold uppercase tracking-wide text-brand shadow-card">
        After
      </span>

      {/* Divider + handle */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 w-1 -translate-x-1/2 bg-white shadow-[0_0_0_1px_rgb(11_37_69/0.15)]"
        style={{ left: `${pos}%` }}
      >
        <span className="absolute left-1/2 top-1/2 grid size-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-4 border-white bg-support text-white shadow-lift">
          <MoveHorizontal className="size-6" strokeWidth={2.5} />
        </span>
      </div>

      <input
        type="range"
        min={0}
        max={100}
        step={1}
        value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        aria-label={label}
        aria-valuetext={`${pos}% before, ${100 - pos}% after`}
        className="absolute inset-0 size-full cursor-ew-resize appearance-none bg-transparent opacity-0"
        style={{ touchAction: "pan-y" }}
      />
    </div>
  );
}
