import { Star } from "lucide-react";
import type { Review } from "@/content/reviews";

export function ReviewCard({ review, index, total }: { review: Review; index: number; total: number }) {
  return (
    <figure
      role="group"
      aria-roledescription="slide"
      aria-label={`${index + 1} of ${total}`}
      data-review-card
      className="flex h-full flex-col rounded-2xl bg-background p-6 shadow-card ring-1 ring-brand/5 sm:p-7"
    >
      <div className="flex gap-1" role="img" aria-label={`${review.stars} out of 5 stars`}>
        {Array.from({ length: 5 }, (_, i) => (
          <Star
            key={i}
            aria-hidden
            className={i < review.stars ? "size-5 fill-support text-support" : "size-5 text-brand/20"}
            strokeWidth={1.5}
          />
        ))}
      </div>
      <blockquote className="mt-4 flex-1 text-[1.0625rem] leading-relaxed text-text">
        <p>&ldquo;{review.quote}&rdquo;</p>
      </blockquote>
      <figcaption className="mt-5 border-t border-brand/10 pt-4">
        <p className="font-extrabold text-brand">
          {review.name}, {review.area}
        </p>
        <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[0.9375rem] text-text/70">
          <span>{review.job}</span>
          <span aria-hidden className="size-1 rounded-full bg-support" />
          <span>{review.when}</span>
        </p>
      </figcaption>
    </figure>
  );
}
