"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { ReviewCard } from "@/components/ReviewCard";
import type { Review } from "@/content/reviews";
import { cn } from "@/lib/cn";

const navButton =
  "grid size-12 place-items-center rounded-full border-2 border-brand bg-white text-brand transition-colors enabled:hover:border-support enabled:hover:bg-support enabled:hover:text-white disabled:cursor-not-allowed disabled:opacity-35";

/**
 * Scroll-snap carousel: no library, no autoplay.
 * 1 card (with a peek of the next) on mobile, 2 on tablet, 3 on desktop.
 * Buttons scroll one card at a time and disable at each end.
 */
export function TestimonialSlider({ reviews }: { reviews: Review[] }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [first, setFirst] = useState(0);
  const [last, setLast] = useState(0);
  const [atStart, setAtStart] = useState(true);
  const [atEnd, setAtEnd] = useState(false);
  const total = reviews.length;

  const measure = useCallback(() => {
    const track = trackRef.current;
    if (!track) return;
    const cards = Array.from(track.querySelectorAll<HTMLElement>("[data-review-card]"));
    const left = track.scrollLeft;
    const right = left + track.clientWidth;
    let f = -1;
    let l = 0;
    cards.forEach((c, i) => {
      const start = c.offsetLeft - track.offsetLeft;
      const end = start + c.offsetWidth;
      if (start >= left - 6 && end <= right + 6) {
        if (f === -1) f = i;
        l = i;
      }
    });
    setFirst(f === -1 ? 0 : f);
    setLast(l);
    setAtStart(left <= 4);
    setAtEnd(left >= track.scrollWidth - track.clientWidth - 4 || l === cards.length - 1);
  }, []);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const raf = requestAnimationFrame(measure);
    const ro = new ResizeObserver(measure);
    ro.observe(track);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [measure]);

  const step = (dir: 1 | -1) => {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector<HTMLElement>("[data-review-card]");
    const gap = parseFloat(getComputedStyle(track).columnGap || "0") || 0;
    const amount = (card?.offsetWidth ?? track.clientWidth) + gap;
    track.scrollBy({ left: dir * amount, behavior: "smooth" });
  };

  const goTo = (index: number) => {
    const track = trackRef.current;
    const card = track?.querySelectorAll<HTMLElement>("[data-review-card]")[index];
    if (track && card) {
      track.scrollTo({ left: card.offsetLeft - track.offsetLeft, behavior: "smooth" });
    }
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      step(1);
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      step(-1);
    }
  };

  return (
    <div role="region" aria-roledescription="carousel" aria-label="Customer reviews (sample)">
      <div
        ref={trackRef}
        tabIndex={0}
        aria-live="polite"
        onScroll={measure}
        onKeyDown={onKeyDown}
        className="snap-track relative -mx-5 flex snap-x snap-mandatory gap-5 overflow-x-auto scroll-smooth px-5 pb-6 pt-1 sm:-mx-8 sm:px-8 lg:mx-0 lg:px-0"
        style={{ scrollPaddingInline: "1.25rem" }}
      >
        {reviews.map((r, i) => (
          <div
            key={r.id}
            className="w-[86%] shrink-0 snap-start sm:w-[calc((100%-1.25rem)/2)] lg:w-[calc((100%-2.5rem)/3)]"
          >
            <ReviewCard review={r} index={i} total={total} />
          </div>
        ))}
      </div>

      <div className="mt-2 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            className={navButton}
            onClick={() => step(-1)}
            disabled={atStart}
            aria-label="Previous review"
          >
            <ChevronLeft aria-hidden className="size-6" strokeWidth={2.75} />
          </button>
          <button
            type="button"
            className={navButton}
            onClick={() => step(1)}
            disabled={atEnd}
            aria-label="Next review"
          >
            <ChevronRight aria-hidden className="size-6" strokeWidth={2.75} />
          </button>
        </div>

        <p className="sr-only">
          Showing reviews {first + 1} to {last + 1} of {total}
        </p>

        <div className="flex items-center" role="group" aria-label="Choose review">
          {reviews.map((r, i) => {
            const visible = i >= first && i <= last;
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => goTo(i)}
                aria-label={`Go to review ${i + 1}`}
                aria-current={visible ? "true" : undefined}
                className="grid size-12 place-items-center"
              >
                <span
                  className={cn(
                    "block rounded-full transition-all",
                    visible ? "h-3 w-6 bg-brand" : "size-3 bg-brand/25",
                  )}
                />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
