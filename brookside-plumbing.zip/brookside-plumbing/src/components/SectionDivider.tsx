import { cn } from "@/lib/cn";

type Tone = "white" | "background" | "brand";

const BG: Record<Tone, string> = {
  white: "bg-white",
  background: "bg-background",
  brand: "bg-brand",
};
const FILL: Record<Tone, string> = {
  white: "fill-white",
  background: "fill-background",
  brand: "fill-brand",
};

type Props = {
  variant: "wave" | "line";
  /** Background colour of the section above */
  from: Tone;
  /** Background colour of the section below */
  to: Tone;
};

/**
 * Animated section divider (replaces a plain border).
 * wave: path filled with the next section's colour drifts sideways in a loop.
 * line: thin support-blue line draws itself in once, with a water drop travelling along it.
 */
export function SectionDivider({ variant, from, to }: Props) {
  if (variant === "wave") {
    return (
      <div aria-hidden="true" className={cn("relative h-9 overflow-hidden sm:h-14 md:h-16", BG[from])}>
        <div data-observe className="wave-drift absolute inset-y-0 left-0 w-[200%]">
          <svg
            viewBox="0 0 2880 80"
            preserveAspectRatio="none"
            className={cn("block h-full w-full", FILL[to])}
          >
            <path d="M0 40 C240 0 480 0 720 40 S1200 80 1440 40 S1920 0 2160 40 S2640 80 2880 40 V80 H0 Z" />
          </svg>
        </div>
      </div>
    );
  }

  return (
    <div aria-hidden="true" className="relative h-10 sm:h-12">
      <div className={cn("absolute inset-x-0 top-0 h-1/2", BG[from])} />
      <div className={cn("absolute inset-x-0 bottom-0 h-1/2", BG[to])} />
      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2">
        <div className="mx-auto w-full max-w-6xl px-5 sm:px-8">
          <div data-observe data-once className="line-box relative h-2">
            <svg
              viewBox="0 0 1000 2"
              preserveAspectRatio="none"
              className="absolute left-0 top-1/2 block h-[2px] w-full -translate-y-1/2 overflow-visible"
            >
              <path
                d="M0 1 H1000"
                pathLength={1}
                className="line-path stroke-support"
                strokeWidth={2}
                strokeLinecap="round"
                fill="none"
              />
            </svg>
            <span className="drop-dot absolute left-0 top-1/2 -mt-[7px] block">
              <span className="block size-3.5 rotate-45 rounded-full rounded-tl-none bg-support" />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
