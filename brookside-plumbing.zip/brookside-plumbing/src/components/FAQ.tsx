"use client";

import { ChevronDown } from "lucide-react";
import { useId, useState } from "react";
import type { Faq } from "@/content/faqs";
import { cn } from "@/lib/cn";

/** Accessible accordion: buttons inside headings, aria-expanded, region panels. First item open. */
export function FAQ({ items }: { items: Faq[] }) {
  const uid = useId();
  const [openId, setOpenId] = useState<string | null>(items[0]?.id ?? null);

  return (
    <div className="divide-y divide-brand/10 overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-brand/5">
      {items.map((item) => {
        const open = openId === item.id;
        const buttonId = `${uid}-${item.id}-btn`;
        const panelId = `${uid}-${item.id}-panel`;
        return (
          <div key={item.id}>
            <h3 className="text-base tracking-normal">
              <button
                id={buttonId}
                type="button"
                aria-expanded={open}
                aria-controls={panelId}
                onClick={() => setOpenId(open ? null : item.id)}
                className="flex min-h-14 w-full items-center justify-between gap-4 px-5 py-2.5 text-left text-base font-extrabold text-brand transition-colors hover:bg-support/[0.05] sm:px-6 sm:text-[1.0625rem]"
              >
                <span>{item.q}</span>
                <span
                  aria-hidden
                  className={cn(
                    "grid size-8 shrink-0 place-items-center rounded-full bg-support/10 text-support transition-transform duration-300",
                    open && "rotate-180",
                  )}
                >
                  <ChevronDown className="size-[18px]" strokeWidth={3} />
                </span>
              </button>
            </h3>
            <div
              id={panelId}
              role="region"
              aria-labelledby={buttonId}
              className={cn(
                "grid transition-[grid-template-rows] duration-300 ease-out",
                open ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
              )}
            >
              <div className="overflow-hidden">
                <p className="px-5 pb-4 pr-12 text-base leading-relaxed text-text/85 sm:px-6">
                  {item.a}
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
