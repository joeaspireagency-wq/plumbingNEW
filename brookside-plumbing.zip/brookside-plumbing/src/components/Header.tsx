import { Droplet, Phone } from "lucide-react";
import { Container } from "@/components/Container";
import { MobileMenu } from "@/components/MobileMenu";
import { NAV_LINKS, SITE } from "@/config/site";

export function Wordmark({ light = false }: { light?: boolean }) {
  return (
    <a href="#top" className="flex min-h-12 shrink-0 items-center gap-3 whitespace-nowrap">
      <span
        className={
          light
            ? "grid size-10 place-items-center rounded-xl bg-white/10 text-white ring-1 ring-white/20"
            : "grid size-10 place-items-center rounded-xl bg-brand text-white"
        }
      >
        <Droplet aria-hidden className="size-5 fill-support text-support" strokeWidth={2} />
      </span>
      <span className="leading-none">
        <span className={light ? "block text-xl font-extrabold text-white" : "block text-xl font-extrabold text-brand"}>
          Brookside
        </span>
        <span
          className={
            light
              ? "mt-1 block text-[0.8125rem] font-bold uppercase tracking-[0.14em] text-white/75"
              : "mt-1 block text-[0.8125rem] font-bold uppercase tracking-[0.14em] text-text/65"
          }
        >
          Plumbing · {SITE.city}
        </span>
      </span>
    </a>
  );
}

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-brand/10 bg-white/92 backdrop-blur-md">
      <Container className="relative flex h-[4.5rem] items-center justify-between gap-4">
        <Wordmark />

        <nav aria-label="Main" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {NAV_LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="inline-flex min-h-12 items-center rounded-lg px-3 font-extrabold text-brand/85 transition-colors hover:text-brand hover:underline hover:decoration-support hover:decoration-2 hover:underline-offset-8"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-4">
          <a
            href={`tel:${SITE.phone.tel}`}
            className="hidden min-h-12 items-center gap-2 whitespace-nowrap font-extrabold text-brand underline-offset-4 hover:underline lg:inline-flex"
          >
            <Phone aria-hidden className="size-4 text-support" strokeWidth={2.5} />
            {SITE.phone.display}
          </a>
          <MobileMenu />
        </div>
      </Container>
    </header>
  );
}
