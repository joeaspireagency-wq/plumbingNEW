import {
  Award,
  Bath,
  BadgeCheck,
  CircleCheckBig,
  Clock,
  Droplets,
  Heater,
  House,
  MessageCircleQuestionMark,
  ShieldCheck,
  Siren,
  Waves,
  Wrench,
  type LucideIcon,
} from "lucide-react";

export const SERVICE_ICONS: Record<string, LucideIcon> = {
  droplets: Droplets,
  wrench: Wrench,
  waves: Waves,
  heater: Heater,
  bath: Bath,
  siren: Siren,
  help: MessageCircleQuestionMark,
  house: House,
};

export const PROMISE_ICONS: Record<string, LucideIcon> = {
  shield: ShieldCheck,
  badge: BadgeCheck,
  tick: CircleCheckBig,
  clock: Clock,
};

export const TRUST_ICONS: Record<string, LucideIcon> = {
  water: Droplets,
  member: BadgeCheck,
  insured: ShieldCheck,
  guarantee: Award,
};
