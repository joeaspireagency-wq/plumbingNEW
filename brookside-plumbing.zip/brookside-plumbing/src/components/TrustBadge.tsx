import { TRUST_ICONS } from "@/components/icons";

export function TrustBadge({
  title,
  detail,
  icon,
}: {
  title: string;
  detail: string;
  icon: string;
}) {
  const Icon = TRUST_ICONS[icon] ?? TRUST_ICONS.guarantee;
  return (
    <li className="flex items-center gap-3.5">
      <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-support/10 text-support">
        <Icon aria-hidden className="size-6" strokeWidth={2} />
      </span>
      <span className="leading-tight">
        <span className="block font-extrabold text-brand">{title}</span>
        <span className="mt-0.5 block text-[0.9375rem] text-text/70">{detail}</span>
      </span>
    </li>
  );
}
