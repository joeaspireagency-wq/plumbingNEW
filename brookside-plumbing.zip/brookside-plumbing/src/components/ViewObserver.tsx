"use client";

import { useInViewToggle } from "@/hooks/useInViewToggle";

/** Mounts the off-screen animation pause hook once for the whole page. */
export function ViewObserver() {
  useInViewToggle();
  return null;
}
