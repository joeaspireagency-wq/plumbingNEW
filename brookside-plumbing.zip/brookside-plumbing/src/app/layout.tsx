import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { SITE } from "@/config/site";
import "./globals.css";

/** One family, two weights, self-hosted at build time. */
const manrope = localFont({
  src: [
    { path: "../fonts/manrope-500.woff2", weight: "500", style: "normal" },
    { path: "../fonts/manrope-800.woff2", weight: "800", style: "normal" },
  ],
  variable: "--font-manrope",
  display: "swap",
  fallback: ["system-ui", "Segoe UI", "Arial", "sans-serif"],
});

const TITLE = "Plumber in Nottingham | Brookside Plumbing";

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: TITLE,
  description: SITE.description,
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "en_GB",
    url: "/",
    siteName: SITE.name,
    title: TITLE,
    description: SITE.description,
    images: [{ url: "/images/og-image.png", width: 1200, height: 630, alt: "Brookside Plumbing, Nottingham" }],
  },
  twitter: {
    card: "summary_large_image",
    title: TITLE,
    description: SITE.description,
    images: ["/images/og-image.png"],
  },
  // SAMPLE CONTENT: a fictional business, so it stays out of search indexes by default.
  // Set NEXT_PUBLIC_ALLOW_INDEXING=1 when this becomes a real client site.
  robots:
    process.env.NEXT_PUBLIC_ALLOW_INDEXING === "1"
      ? { index: true, follow: true }
      : { index: false, follow: false },
};

export const viewport: Viewport = {
  themeColor: "#0B2545",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB" className={manrope.variable}>
      <body id="top" className="font-sans">
        {children}
      </body>
    </html>
  );
}
