import type { Metadata } from "next";
import Link from "next/link";
import { Container } from "@/components/Container";
import { SITE } from "@/config/site";

export const metadata: Metadata = {
  title: "Legal (placeholder) | Brookside Plumbing",
  robots: { index: false, follow: false },
};

const sections = [
  { id: "privacy", title: "Privacy" },
  { id: "terms", title: "Terms" },
  { id: "guarantee", title: "Guarantee terms" },
];

/** Placeholder page for the prototype. Replace with real documents before launch. */
export default function LegalPlaceholder() {
  return (
    <main className="min-h-dvh bg-background py-16">
      <Container className="max-w-2xl">
        <Link href="/" className="text-link inline-flex min-h-12 items-center">
          Back to {SITE.name}
        </Link>
        <h1 className="mt-6 text-4xl">Legal pages (placeholder)</h1>
        <p className="mt-4 text-lg text-text/80">
          This is a prototype with sample content. Replace each section below with your real privacy
          policy, terms and guarantee terms before going live.
        </p>
        {sections.map((s) => (
          <section key={s.id} id={s.id} className="mt-10 rounded-2xl bg-white p-6 shadow-card">
            <h2 className="text-2xl">{s.title}</h2>
            <p className="mt-3 text-text/80">Placeholder text. Add your {s.title.toLowerCase()} here.</p>
          </section>
        ))}
      </Container>
    </main>
  );
}
