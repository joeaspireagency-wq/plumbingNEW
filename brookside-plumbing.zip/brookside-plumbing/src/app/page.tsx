import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { QuoteForm } from "@/components/QuoteForm";
import { SectionDivider } from "@/components/SectionDivider";
import { WhatsAppFloat } from "@/components/WhatsAppFloat";
import { ViewObserver } from "@/components/ViewObserver";
import { About } from "@/components/sections/About";
import { FaqSection } from "@/components/sections/FaqSection";
import { FinalCta } from "@/components/sections/FinalCta";
import { Hero } from "@/components/sections/Hero";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Pricing } from "@/components/sections/Pricing";
import { Programs } from "@/components/sections/Programs";
import { SocialProof } from "@/components/sections/SocialProof";
import { TrustBar } from "@/components/sections/TrustBar";
import { SITE } from "@/config/site";
import { faqs } from "@/content/faqs";

/* SAMPLE CONTENT: Brookside Plumbing is a fictional business. */

const localBusiness = {
  "@context": "https://schema.org",
  "@type": "Plumber",
  name: SITE.name,
  description: SITE.description,
  url: SITE.url,
  telephone: SITE.phone.tel,
  email: SITE.email,
  image: `${SITE.url}/images/og-image.png`,
  priceRange: "££",
  address: { "@type": "PostalAddress", addressLocality: SITE.city, addressCountry: "GB" },
  areaServed: [
    ...SITE.areas.postcodes.map((p) => ({ "@type": "AdministrativeArea", name: p })),
    ...SITE.areas.towns.map((t) => ({ "@type": "City", name: t })),
  ],
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      opens: SITE.hours.opens,
      closes: SITE.hours.closes,
    },
  ],
  founder: { "@type": "Person", name: SITE.owner.name },
};

const faqPage = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a },
  })),
};

/** Escape "<" so the JSON can never close the script tag. */
const json = (data: unknown) => JSON.stringify(data).replace(/</g, "\\u003c");

export default function Page() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <TrustBar />
        <SectionDivider variant="wave" from="white" to="background" />
        <Programs />
        <SectionDivider variant="line" from="background" to="white" />
        <Pricing />
        <SectionDivider variant="wave" from="white" to="background" />
        <HowItWorks />
        <SectionDivider variant="line" from="background" to="white" />
        <SocialProof />
        <About />
        <SectionDivider variant="wave" from="white" to="background" />
        <FaqSection />
        <FinalCta />
      </main>
      <Footer />

      <QuoteForm />
      <WhatsAppFloat />
      <ViewObserver />

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: json(localBusiness) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: json(faqPage) }} />
    </>
  );
}
