/**
 * SAMPLE CONTENT: Brookside Plumbing is a fictional business used to demonstrate
 * what a professional UK plumber's website can look like.
 *
 * This file is the single place to personalise the template for a real business.
 */
import { z } from "zod";

const SiteSchema = z.object({
  name: z.string().min(1),
  tagline: z.string().min(1),
  description: z.string().min(1),
  url: z.string().url(),
  owner: z.object({
    name: z.string(),
    firstName: z.string(),
    age: z.number(),
    apprentice: z.string(),
    yearsExperience: z.number(),
    soloSince: z.number(),
  }),
  city: z.string(),
  phone: z.object({ display: z.string(), tel: z.string() }),
  mobile: z.object({ display: z.string(), tel: z.string() }),
  whatsapp: z.object({ number: z.string().regex(/^\d{8,15}$/), message: z.string() }),
  email: z.string().email(),
  hours: z.object({
    summary: z.string(),
    emergency: z.string(),
    opens: z.string(),
    closes: z.string(),
  }),
  areas: z.object({
    postcodes: z.array(z.string()).min(1),
    towns: z.array(z.string()).min(1),
  }),
  accreditations: z.array(z.object({ name: z.string(), detail: z.string() })),
  insurance: z.string(),
  guarantee: z.string(),
  rating: z.object({ score: z.string(), jobs: z.string() }),
  responseTime: z.object({
    working: z.string(),
    emergency: z.string(),
    emergencyMinutes: z.number(),
  }),
});

export type SiteConfig = z.infer<typeof SiteSchema>;

export const SITE: SiteConfig = SiteSchema.parse({
  name: "Brookside Plumbing",
  tagline: "Plumber in Nottingham",
  description:
    "Nottingham plumber with fixed prices in writing, a 5-year workmanship guarantee and 24/7 emergency cover. Tell us the problem and get a free quote, usually within the hour.",
  url: "https://brooksideplumbing.example",
  owner: {
    name: "Liam Hartnett",
    firstName: "Liam",
    age: 38,
    apprentice: "Jake",
    yearsExperience: 14,
    soloSince: 6,
  },
  city: "Nottingham",
  phone: { display: "+44 7340 843589", tel: "+447340843589" },
  mobile: { display: "+44 7340 843589", tel: "+447340843589" },
  /** International format, digits only, no + (used for the wa.me link). */
  whatsapp: { number: "447340843589", message: "Hi Brookside, I'd like a quote for a plumbing job." },
  email: "hello@brooksideplumbing.example",
  hours: {
    summary: "Mon–Sat 7:30–18:00",
    emergency: "Emergency line 24/7",
    opens: "07:30",
    closes: "18:00",
  },
  areas: {
    postcodes: ["NG1", "NG2", "NG3", "NG4", "NG5", "NG6", "NG7", "NG8", "NG9"],
    towns: ["West Bridgford", "Beeston", "Arnold", "Carlton"],
  },
  accreditations: [
    { name: "WaterSafe registered", detail: "Approved plumber scheme" },
    { name: "CIPHE member", detail: "Chartered plumbing body" },
  ],
  insurance: "£2m public liability insurance",
  guarantee: "5-year workmanship guarantee",
  rating: { score: "4.9", jobs: "120+" },
  responseTime: {
    working: "within 1 hour in working hours",
    emergency: "within 15 minutes",
    emergencyMinutes: 15,
  },
});

/** The ONE primary call to action. Use exactly this label everywhere. */
export const CTA_LABEL = "Get Your Free Quote" as const;

export const CTA_MICROCOPY =
  "Fixed price in writing. No obligation. Reply within 1 hour in working hours.";

export const NAV_LINKS = [
  { href: "#services", label: "Services" },
  { href: "#pricing", label: "Pricing" },
  { href: "#reviews", label: "Reviews" },
  { href: "#faq", label: "FAQ" },
] as const;

export const PROOF_LINE = `${SITE.rating.score}★ from ${SITE.rating.jobs} local jobs · Insured · 5-year guarantee`;

/** Placeholder legal pages: swap for real documents before going live. */
export const LEGAL_LINKS = [
  { href: "/legal#privacy", label: "Privacy" },
  { href: "/legal#terms", label: "Terms" },
  { href: "/legal#guarantee", label: "Guarantee terms" },
] as const;
