/**
 * Quote submission adapter.
 *
 * DEMO MODE: this prototype never sends data anywhere. `submitQuote` validates,
 * waits a moment, and returns success. Nothing leaves the browser.
 *
 * TODO (going live): swap the demo branch for a free form service, using the
 * official docs for whichever you choose:
 *   - Web3Forms: https://docs.web3forms.com  (POST JSON to their submit endpoint
 *     with your public access key; read the response's `success` flag)
 *   - Formspree: https://help.formspree.io  (POST JSON to your form's endpoint
 *     with an `Accept: application/json` header; check `response.ok`)
 * Keep the try/catch and the QuoteResult shape so the form UI needs no changes.
 * Put any key in an env var (NEXT_PUBLIC_*), never in the repo.
 */
import { z } from "zod";
import { SITE } from "@/config/site";
import { SERVICE_IDS } from "@/content/services";

export const DEMO_MODE = true;
/** Set true to preview the error state in demo mode. */
const DEMO_FORCE_ERROR = false;

export const FALLBACK_MESSAGE = `Something went wrong, please call ${SITE.phone.display}`;

const UK_POSTCODE = /^[A-Za-z]{1,2}\d[A-Za-z\d]?\s?\d[A-Za-z]{2}$/;
const UK_MOBILE = /^(?:\+44|0044|0)7\d{9}$/;

export const TIMES = [
  { id: "emergency", label: "Emergency, right now", hint: "Flooding, burst pipe or no water" },
  { id: "today", label: "Today", hint: "As soon as we can get to you" },
  { id: "tomorrow", label: "Tomorrow", hint: "Next available slot" },
  { id: "this-week", label: "This week", hint: "Any day that suits you" },
] as const;

export const WHEN_IDS = ["emergency", "today", "tomorrow", "this-week"] as const;

/** Page 1: what do you need? */
export const stepOneSchema = z.object({
  service: z.enum(SERVICE_IDS, { error: "Choose what you need so we can price it properly." }),
});

/** Page 2: how soon? */
export const stepTwoSchema = z.object({
  when: z.enum(WHEN_IDS, { error: "Pick when suits you." }),
});

/** Page 3: where are you? */
export const stepThreeSchema = z.object({
  postcode: z
    .string()
    .trim()
    .min(1, "Enter your postcode.")
    .regex(UK_POSTCODE, "That doesn't look like a UK postcode. Try something like NG1 1AA."),
});

/** Page 4: how do we reach you? */
export const stepFourSchema = z.object({
  name: z.string().trim().min(2, "Tell us your name.").max(60, "Keep your name under 60 characters."),
  mobile: z
    .string()
    .trim()
    .min(1, "Enter a mobile number so we can reach you.")
    .refine(
      (v) => UK_MOBILE.test(v.replace(/[\s()-]/g, "")),
      "That doesn't look like a UK mobile. Try something like 07700 900123.",
    ),
  note: z.string().trim().max(200, "Keep the note under 200 characters.").optional(),
});

export const quoteSchema = z.object({
  ...stepOneSchema.shape,
  ...stepTwoSchema.shape,
  ...stepThreeSchema.shape,
  ...stepFourSchema.shape,
  emergency: z.boolean(),
});

export type QuoteInput = z.infer<typeof quoteSchema>;

export type QuoteResult =
  | { ok: true; demo: boolean; emergency: boolean; name: string; replyCopy: string }
  | { ok: false; message: string };

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export async function submitQuote(input: unknown): Promise<QuoteResult> {
  try {
    const parsed = quoteSchema.safeParse(input);
    if (!parsed.success) {
      return { ok: false, message: parsed.error.issues[0]?.message ?? FALLBACK_MESSAGE };
    }
    const data = parsed.data;

    if (DEMO_MODE) {
      await sleep(900);
      if (DEMO_FORCE_ERROR) throw new Error("Demo error");
      return {
        ok: true,
        demo: true,
        emergency: data.emergency,
        name: data.name,
        replyCopy: data.emergency
          ? `Liam will ring you back ${SITE.responseTime.emergency}.`
          : `We'll text you ${SITE.responseTime.working}.`,
      };
    }

    // TODO: live submission goes here (see the note at the top of this file).
    throw new Error("Live submission is not configured.");
  } catch {
    return { ok: false, message: FALLBACK_MESSAGE };
  }
}
