// Renders public/images/og-image.png (1200x630) from the brand tokens. Dev-only.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const font = readFileSync(path.join(root, "src/fonts/manrope-800.woff2")).toString("base64");
const html = `<!doctype html><html><head><style>
@font-face{font-family:M;src:url(data:font/woff2;base64,${font}) format("woff2");font-weight:800}
*{box-sizing:border-box;margin:0}
body{width:1200px;height:630px;font-family:M,Arial,sans-serif;font-weight:800;color:#fff;
background:linear-gradient(135deg,#0B2545 0%,#13315C 60%,#1B4079 100%);position:relative;overflow:hidden;padding:72px 80px}
.c1{position:absolute;right:-120px;top:-140px;width:520px;height:520px;border-radius:50%;background:rgba(255,255,255,.07)}
.c2{position:absolute;right:140px;bottom:-160px;width:360px;height:360px;border-radius:50%;border:3px solid rgba(2,132,199,.45)}
.c3{position:absolute;left:-90px;bottom:-110px;width:300px;height:300px;border-radius:50%;background:rgba(2,132,199,.16)}
.brand{display:flex;align-items:center;gap:18px;font-size:34px;position:relative}
.drop{width:60px;height:60px;border-radius:16px;background:rgba(255,255,255,.1);border:2px solid rgba(255,255,255,.2);display:grid;place-items:center}
.drop i{display:block;width:22px;height:22px;background:#0284C7;border-radius:50% 50% 50% 0;transform:rotate(-45deg) translate(2px,2px)}
.sub{font-size:20px;letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.7);display:block;margin-top:4px}
h1{position:relative;font-size:78px;line-height:1.05;letter-spacing:-.02em;margin-top:70px;max-width:900px}
h1 span{color:rgba(255,255,255,.72)}
.row{position:absolute;left:80px;bottom:64px;display:flex;gap:16px;font-size:24px}
.row b{background:rgba(255,255,255,.1);border:2px solid rgba(255,255,255,.18);padding:12px 22px;border-radius:14px}
</style></head><body><div class="c1"></div><div class="c2"></div><div class="c3"></div>
<div class="brand"><div class="drop"><i></i></div><div>Brookside<span class="sub">Plumbing · Nottingham</span></div></div>
<h1>Nottingham plumber. <span>Tell us the problem, get a fixed price.</span></h1>
<div class="row"><b>Fixed price in writing</b><b>5-year guarantee</b><b>24/7 emergency</b></div>
</body></html>`;

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1200, height: 630 } });
await page.setContent(html);
await page.screenshot({ path: path.join(root, "public/images/og-image.png") });
await browser.close();
console.log("og-image.png written");
