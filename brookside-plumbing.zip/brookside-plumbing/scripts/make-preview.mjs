// Builds ./preview: the static export re-pathed with RELATIVE URLs (so it works under any
// sub-folder), plus a laptop + phone wrapper page. Dev-only helper, not part of the site.
import { cpSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const out = path.join(root, "out");
const prev = path.join(root, "preview");
const site = path.join(prev, "site");

rmSync(prev, { recursive: true, force: true });
mkdirSync(site, { recursive: true });
cpSync(path.join(out, "_next"), path.join(site, "_next"), { recursive: true });
cpSync(path.join(out, "images"), path.join(site, "images"), { recursive: true });
cpSync(path.join(out, "icon.svg"), path.join(site, "icon.svg"));

// 1. HTML: relative asset URLs everywhere (attributes and the inline React payload alike)
let html = readFileSync(path.join(out, "index.html"), "utf8");
html = html.replace(/\/_next\//g, "./_next/");
html = html.replace(/(["'(=])\/images\//g, "$1images/");
html = html.replace(/(["'(=])\/icon\.svg/g, "$1icon.svg");

// 2. Placeholder legal links: show a small toast instead of navigating away
const toast = `<script>(function(){document.addEventListener("click",function(e){var a=e.target&&e.target.closest&&e.target.closest("a[data-legal]");if(!a)return;e.preventDefault();var t=document.getElementById("legal-toast");if(!t){t=document.createElement("div");t.id="legal-toast";t.setAttribute("role","status");t.style.cssText="position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:60;background:#0B2545;color:#fff;padding:14px 20px;border-radius:14px;font:800 15px/1.4 system-ui,sans-serif;box-shadow:0 12px 32px rgba(0,0,0,.3);max-width:90vw;text-align:center";document.body.appendChild(t)}t.textContent="Placeholder page: add your real "+a.textContent.trim().toLowerCase()+" before launch.";t.style.display="block";clearTimeout(t._h);t._h=setTimeout(function(){t.style.display="none"},3200)})})();</script>`;
html = html.replace("</body>", toast + "</body>");
writeFileSync(path.join(site, "index.html"), html);

// 3. Turbopack runtime default chunk base path -> relative
const chunks = path.join(site, "_next/static/chunks");
for (const f of readdirSync(chunks)) {
  if (f.startsWith("turbopack-") && f.endsWith(".js")) {
    const p = path.join(chunks, f);
    writeFileSync(p, readFileSync(p, "utf8").replace(/:"\/_next\/"/g, ':"./_next/"'));
  }
}

// 4. The wrapper page
writeFileSync(path.join(prev, "index.html"), readFileSync(path.join(root, "scripts/preview-wrapper.html"), "utf8"));

// manifest for publishing
const files = [];
(function walk(d) {
  for (const n of readdirSync(d)) {
    const p = path.join(d, n);
    if (statSync(p).isDirectory()) walk(p);
    else files.push(path.relative(prev, p));
  }
})(prev);
writeFileSync(path.join(root, "qa/preview-files.json"), JSON.stringify(files, null, 1));
console.log(files.length + " files in preview/");
