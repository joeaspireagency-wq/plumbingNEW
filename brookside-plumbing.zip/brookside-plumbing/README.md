# Brookside Plumbing

A frontend-only website prototype for a fictional UK plumbing company (Brookside Plumbing, Nottingham, owner Liam Hartnett). It is built to show a tradesperson what their site could look like, with one goal: get the visitor to ask for a free quote.

All content is sample content. Prices, reviews, the project in the before/after slider and the legal pages are placeholders. The quote form runs in demo mode and sends nothing.

## Stack

- Next.js 16 (App Router), React 19, TypeScript (strict)
- Tailwind CSS v4 (design tokens in `src/app/globals.css`)
- Zod for content and form validation
- lucide-react icons, Manrope font (self-hosted)
- No backend, no database, no paid services

## Getting started

```bash
npm install
npm run dev        # http://localhost:3000
```

| Command | What it does |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` | Production build (next/image optimisation on) |
| `npm run start` | Serve the production build |
| `npm run build:static` | Plain static export into `out/` for any static host |
| `npm run preview` | Static export plus a laptop and phone preview page in `preview/` |
| `npm run typecheck` | TypeScript check |
| `npm run lint` | ESLint |
| `npm run qa` | Browser test of the quote popup, WhatsApp button and layout (needs `npm run preview` first) |

`npm run qa` uses Playwright. If Playwright's own browser is not installed, run `npx playwright install chromium`, or point `CHROMIUM_PATH` at an existing Chrome or Chromium.

## How the page works

- **One conversion goal.** The primary button says exactly "Get Your Free Quote". There are only two of them on the page: one in the hero and one in the final block.
- **Quote popup.** The buttons open a dialog (native `<dialog>`), not a link to the bottom of the page. The form has four pages. Tapping a choice on the first two pages moves to the next page automatically.
- **Floating WhatsApp button.** A green pill on mobile, a "Contact us" bubble in the bottom right on laptop.
- **Demo mode.** `submitQuote` in `src/lib/quote.ts` waits a moment and returns success. To go live, replace it with a real request and keep the key in a `NEXT_PUBLIC_*` environment variable, never in the repo.

## Where to change things

| What | Where |
| --- | --- |
| Business name, phone, WhatsApp number, hours, areas, owner details | `src/config/site.ts` |
| Navigation links and button label | `src/config/site.ts` |
| Prices | `src/content/pricing.ts` |
| Reviews and the before/after project | `src/content/reviews.ts`, `src/content/beforeAfter.ts` |
| Services and service cards | `src/content/services.ts` |
| FAQ | `src/content/faqs.ts` |
| How it works steps and trust badges | `src/content/promises.ts` |
| Images (paths, alt text, focal points) | `src/content/images.ts` and `public/images/` |
| Colours and spacing tokens | `src/app/globals.css` |
| Page order | `src/app/page.tsx` |

Design tokens: brand `#0B2545`, call-to-action `#EA580C`, support `#0284C7`, background `#F8FAFC`.

### Images

All images are hosted locally in `public/images/`. See `public/images/README.md` for the size and ratio of each slot. Each image has alt text in `src/content/images.ts`.

## Going live

1. Replace the sample content, phone and WhatsApp numbers in `src/config/site.ts`.
2. Replace the placeholder legal pages at `src/app/legal/page.tsx` with real documents.
3. Connect the quote form to a real endpoint in `src/lib/quote.ts`.
4. Set `NEXT_PUBLIC_ALLOW_INDEXING=1` so search engines can index the site. It is off by default so the prototype is not indexed.
5. Update `url` in `src/config/site.ts`.

### Hosting for free

- **Vercel (free tier):** import the repo and deploy. No settings needed.
- **Any static host (GitHub Pages, Cloudflare Pages, Netlify):** run `npm run build:static` and upload the `out/` folder.

## Project layout

```
src/
  app/            page, layout, legal page, global styles
  components/     header, hero, quote form, WhatsApp button, shared pieces
    sections/     one file per page section
  config/         site details (single source of truth)
  content/        sample content, validated with Zod
  lib/            form validation and the demo submit
public/images/    all photos and the share image
scripts/          preview builder and share-image generator
qa/               browser test for the popup, WhatsApp button and layout
```

## Accessibility

Real buttons and headings, keyboard-friendly popup and accordion, visible focus, labelled form fields with clear error messages, reduced-motion support, and no content that depends on hover.
