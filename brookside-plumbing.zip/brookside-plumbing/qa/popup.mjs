import { chromium } from "playwright";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve("preview");
const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".woff2": "font/woff2", ".md": "text/markdown" };
const CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; frame-src 'self'";
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p.endsWith("/")) p += "index.html";
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f)) { res.writeHead(404); return res.end("nf"); }
  res.writeHead(200, { "content-type": MIME[path.extname(f)] || "application/octet-stream", "content-security-policy": CSP });
  fs.createReadStream(f).pipe(res);
}).listen(4200);

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined, args: ["--no-sandbox"] });
const results = [];
const ok = (name, pass, extra = "") => results.push({ name, pass, extra });
const SITE = "http://localhost:4200/site/index.html";
fs.mkdirSync("qa/shots", { recursive: true });

async function run(label, viewport, isMobile) {
  const ctx = await browser.newContext({ viewport, isMobile, hasTouch: isMobile, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
  await page.goto(SITE, { waitUntil: "networkidle" });

  // --- only two CTAs ---
  const info = await page.evaluate(() => ({
    triggers: [...document.querySelectorAll("[data-quote-open]")].map((e) => ({ tag: e.tagName, text: e.textContent.trim(), inHero: !!e.closest("#hero"), inFinal: !!e.closest("#final-cta") })),
    btnCta: document.querySelectorAll(".btn-cta").length,
    hashLinks: document.querySelectorAll('a[href="#quote"]').length,
    text: document.body.innerText,
  }));
  ok(`${label}: exactly 2 CTA triggers (hero + final)`, info.triggers.length === 2 && info.triggers.filter((t) => t.inHero).length === 1 && info.triggers.filter((t) => t.inFinal).length === 1, JSON.stringify(info.triggers));
  ok(`${label}: CTAs are <button> labelled exactly`, info.triggers.every((t) => t.tag === "BUTTON" && t.text === "Get Your Free Quote"));
  ok(`${label}: no other .btn-cta, no #quote links`, info.btnCta === 2 && info.hashLinks === 0, `btn-cta=${info.btnCta} links=${info.hashLinks}`);
  ok(`${label}: removed copy is gone`, !/Jobs we get called|Every job includes|Quote this job|Tell us about your job/.test(info.text));

  // --- popup opens, page does not jump ---
  const y0 = await page.evaluate(() => scrollY);
  await page.click("#hero button[data-quote-open]");
  await page.waitForSelector("dialog[open]");
  const y1 = await page.evaluate(() => scrollY);
  const hash = await page.evaluate(() => location.hash);
  ok(`${label}: hero CTA opens popup, no jump, no hash`, y0 === y1 && hash === "", `y ${y0}->${y1} hash="${hash}"`);
  await page.waitForTimeout(350);
  await page.screenshot({ path: `qa/shots/pop-${label}-1.png` });

  // --- auto advance ---
  const h2 = () => page.textContent("dialog h2");
  ok(`${label}: page 1 heading`, (await h2()) === "What do you need?");
  await page.click("dialog button:has-text('Blocked drains')");
  await page.waitForFunction(() => document.querySelector("dialog h2")?.textContent === "How soon?", null, { timeout: 2000 });
  ok(`${label}: one tap on a job auto-opens page 2`, true);
  await page.waitForTimeout(350);
  await page.screenshot({ path: `qa/shots/pop-${label}-2.png` });
  await page.click("dialog button:has-text('Tomorrow')");
  await page.waitForFunction(() => document.querySelector("dialog h2")?.textContent === "Where are you?", null, { timeout: 2000 });
  ok(`${label}: one tap on timing auto-opens page 3`, true);
  ok(`${label}: page 3 shows Step 3 of 4`, /Step 3 of 4/.test(await page.textContent("dialog")));

  // validation + back
  await page.fill("dialog input[name=postcode]", "XYZ");
  await page.keyboard.press("Enter");
  ok(`${label}: Enter on bad postcode shows error`, /postcode/i.test((await page.textContent("dialog [role=alert]").catch(() => "")) ?? ""));
  await page.fill("dialog input[name=postcode]", "ng1 1aa");
  await page.keyboard.press("Enter");
  await page.waitForSelector("dialog input[name=mobile]");
  ok(`${label}: Enter on valid postcode opens page 4`, (await h2()) === "How do we reach you?");
  await page.click("dialog button:has-text('Back')");
  ok(`${label}: Back keeps postcode`, (await page.inputValue("dialog input[name=postcode]")).toLowerCase() === "ng1 1aa");
  await page.click("dialog button:has-text('Continue')");
  await page.waitForSelector("dialog input[name=mobile]");
  await page.click("dialog button:has-text('Send my request')");
  ok(`${label}: empty contact page shows errors`, (await page.$$("dialog [role=alert]")).length >= 2);
  await page.fill("dialog input[name=name]", "Sam Taylor");
  await page.fill("dialog input[name=mobile]", "07700 900123");
  await page.screenshot({ path: `qa/shots/pop-${label}-4.png` });
  await page.click("dialog button:has-text('Send my request')");
  await page.waitForSelector("dialog :text('Demo only: no data was sent.')", { timeout: 4000 });
  ok(`${label}: success page, demo notice`, true);
  await page.screenshot({ path: `qa/shots/pop-${label}-5.png` });
  await page.click("dialog button:has-text('Close')");
  await page.waitForFunction(() => !document.querySelector("dialog[open]"));
  ok(`${label}: popup closes`, true);

  // final CTA opens popup fresh at page 1
  await page.evaluate(() => document.getElementById("final-cta").scrollIntoView());
  await page.waitForTimeout(400);
  await page.click("#final-cta button[data-quote-open]");
  await page.waitForSelector("dialog[open]");
  ok(`${label}: final CTA opens popup fresh on page 1`, (await h2()) === "What do you need?");
  await page.keyboard.press("Escape");

  // --- WhatsApp ---
  await page.evaluate(() => scrollTo(0, 0));
  await page.waitForTimeout(200);
  const wa = await page.evaluate(() => {
    const vis = [...document.querySelectorAll('a[href^="https://wa.me/"]')].filter((a) => a.getBoundingClientRect().width > 0);
    return vis.map((a) => { const r = a.getBoundingClientRect(); return { text: a.textContent.trim(), right: Math.round(innerWidth - r.right), bottom: Math.round(innerHeight - r.bottom), w: Math.round(r.width), h: Math.round(r.height), fixed: getComputedStyle(a.parentElement).position, target: a.target }; });
  });
  ok(`${label}: exactly one WhatsApp link visible`, wa.length === 1, JSON.stringify(wa));
  if (label === "laptop") ok("laptop: 'Contact us' + icon, bottom-right corner", wa[0]?.text === "Contact us" && wa[0].right <= 40 && wa[0].bottom <= 40, JSON.stringify(wa[0]));
  else ok("mobile: 'Message us on WhatsApp' pill + icon along bottom", wa[0]?.text === "Message us on WhatsApp" && wa[0].bottom <= 24, JSON.stringify(wa[0]));
  ok(`${label}: WhatsApp link opens externally`, wa[0]?.target === "_blank");
  await page.screenshot({ path: `qa/shots/wa-${label}-hero.png` });
  await page.evaluate(() => scrollTo(0, document.documentElement.scrollHeight));
  await page.waitForTimeout(300);
  await page.screenshot({ path: `qa/shots/wa-${label}-footer.png` });
  const over = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1);
  ok(`${label}: no horizontal overflow`, !over);
  // footer bottom text not covered by the WhatsApp button
  const cover = await page.evaluate(() => {
    const a = [...document.querySelectorAll('a[href^="https://wa.me/"]')].find((x) => x.getBoundingClientRect().width > 0).getBoundingClientRect();
    const items = [...document.querySelectorAll("footer p, footer a")].filter((e) => { const r = e.getBoundingClientRect(); return r.width && r.height && !(r.right < a.left || r.left > a.right || r.bottom < a.top || r.top > a.bottom); });
    return items.map((e) => e.textContent.trim().slice(0, 30));
  });
  ok(`${label}: WhatsApp button covers no footer text at page end`, cover.length === 0, cover.join("|"));
  ok(`${label}: no page errors under viewer-like CSP`, errors.length === 0, errors.join(" || "));
  await ctx.close();
}

await run("laptop", { width: 1440, height: 900 }, false);
await run("mobile", { width: 390, height: 844 }, true);

// nested inside the preview wrapper (iframes), like the real viewer
{
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("http://localhost:4200/", { waitUntil: "networkidle" });
  await page.waitForTimeout(800);
  const frames = page.frames().filter((f) => f.url().includes("/site/"));
  ok("wrapper: both iframes loaded", frames.length === 2, String(frames.length));
  const phone = frames.find((f) => f.name?.includes?.("phone")) ?? frames[1];
  await phone.click("#hero button[data-quote-open]");
  await phone.waitForSelector("dialog[open]");
  await phone.click("dialog button:has-text('Leaks and bursts')");
  await phone.waitForFunction(() => document.querySelector("dialog h2")?.textContent === "How soon?", null, { timeout: 2000 });
  ok("wrapper: popup + auto-advance work inside the phone frame", true);
  await page.waitForTimeout(400);
  await page.screenshot({ path: "qa/shots/wrapper-popup.png" });
  ok("wrapper: no page errors", errors.length === 0, errors.join("||"));
  await ctx.close();
}

await browser.close();
server.close();
let bad = 0;
for (const r of results) { if (!r.pass) bad++; console.log(`${r.pass ? "PASS" : "FAIL"}  ${r.name}${r.pass && !r.extra ? "" : "  " + r.extra.slice(0, 300)}`); }
console.log(`\n${results.length - bad}/${results.length} passed`);
process.exit(bad ? 1 : 0);
